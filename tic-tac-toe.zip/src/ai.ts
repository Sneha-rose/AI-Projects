/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BoardState, Player } from './types';

export const WINNING_COMBINATIONS = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
  [0, 4, 8], [2, 4, 6]             // Diagonals
];

/**
 * Check if a player has won on the given board
 */
export function checkWinner(board: BoardState): { winner: Player; combination: number[] } | null {
  for (const combo of WINNING_COMBINATIONS) {
    const [a, b, c] = combo;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a] as Player, combination: combo };
    }
  }
  return null;
}

/**
 * Check if the board is full (draw)
 */
export function isBoardFull(board: BoardState): boolean {
  return board.every(cell => cell !== null);
}

/**
 * Get all available cell indices
 */
function getEmptyIndices(board: BoardState): number[] {
  return board
    .map((cell, index) => (cell === null ? index : -1))
    .filter(index => index !== -1);
}

/**
 * Minimax evaluation function for unbeatable AI
 */
function minimax(board: BoardState, depth: number, isMaximizing: boolean, aiPlayer: Player, opponent: Player): { score: number; index: number } {
  const winnerInfo = checkWinner(board);
  
  if (winnerInfo) {
    return { score: winnerInfo.winner === aiPlayer ? 10 - depth : depth - 10, index: -1 };
  }
  
  if (isBoardFull(board)) {
    return { score: 0, index: -1 };
  }

  const emptyIndices = getEmptyIndices(board);
  
  if (isMaximizing) {
    let bestScore = -Infinity;
    let bestIndex = -1;
    
    for (const index of emptyIndices) {
      board[index] = aiPlayer;
      const result = minimax(board, depth + 1, false, aiPlayer, opponent);
      board[index] = null; // Backtrack
      
      if (result.score > bestScore) {
        bestScore = result.score;
        bestIndex = index;
      }
    }
    return { score: bestScore, index: bestIndex };
  } else {
    let bestScore = Infinity;
    let bestIndex = -1;
    
    for (const index of emptyIndices) {
      board[index] = opponent;
      const result = minimax(board, depth + 1, true, aiPlayer, opponent);
      board[index] = null; // Backtrack
      
      if (result.score < bestScore) {
        bestScore = result.score;
        bestIndex = index;
      }
    }
    return { score: bestScore, index: bestIndex };
  }
}

/**
 * Computes the computer's move based on the selected difficulty
 */
export function computeComputerMove(
  board: BoardState,
  computerPlayer: Player,
  difficulty: 'easy' | 'medium' | 'hard'
): number {
  const emptyIndices = getEmptyIndices(board);
  if (emptyIndices.length === 0) return -1;

  const humanPlayer: Player = computerPlayer === 'X' ? 'O' : 'X';

  // --- 1. EASY DIFFICULTY ---
  // Purely random moves
  if (difficulty === 'easy') {
    const randomIndex = Math.floor(Math.random() * emptyIndices.length);
    return emptyIndices[randomIndex];
  }

  // --- 2. MEDIUM DIFFICULTY ---
  // Smart win/block moves, otherwise slightly random or center preference
  if (difficulty === 'medium') {
    // A. Check if computer can win in this turn
    for (const index of emptyIndices) {
      const tempBoard = [...board];
      tempBoard[index] = computerPlayer;
      if (checkWinner(tempBoard)?.winner === computerPlayer) {
        return index;
      }
    }

    // B. Check if computer needs to block human player's win
    for (const index of emptyIndices) {
      const tempBoard = [...board];
      tempBoard[index] = humanPlayer;
      if (checkWinner(tempBoard)?.winner === humanPlayer) {
        return index;
      }
    }

    // C. Prefer the center cell (index 4) if available (60% chance to act smart, 40% random)
    if (board[4] === null && Math.random() < 0.6) {
      return 4;
    }

    // D. Fallback to random with a preference for corners
    const corners = [0, 2, 6, 8].filter(idx => board[idx] === null);
    if (corners.length > 0 && Math.random() < 0.5) {
      const randomCorner = Math.floor(Math.random() * corners.length);
      return corners[randomCorner];
    }

    // Final fallback
    const randomIndex = Math.floor(Math.random() * emptyIndices.length);
    return emptyIndices[randomIndex];
  }

  // --- 3. HARD (UNBEATABLE) DIFFICULTY ---
  // Minimax algorithm
  // If board is totally empty (AI plays first), playing center is best and avoids calculation
  if (emptyIndices.length === 9) {
    return 4; // Center
  }

  const { index } = minimax([...board], 0, true, computerPlayer, humanPlayer);
  return index !== -1 ? index : emptyIndices[0];
}
