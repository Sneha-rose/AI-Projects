/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Volume2,
  VolumeX,
  RotateCcw,
  User,
  Cpu,
  Sparkles,
  Palette,
  Settings,
  Trophy,
  History,
  Play,
  ArrowRight,
  RefreshCw,
  Home,
  Info
} from 'lucide-react';

import {
  Player,
  BoardState,
  GameMode,
  Difficulty,
  GameStatus,
  ThemeId,
  GameMove,
  Score
} from './types';
import { THEMES } from './themeData';
import { audioService } from './audio';
import { checkWinner, isBoardFull, computeComputerMove } from './ai';
import { MarkX, MarkO, TurnIndicatorSymbol } from './components/Symbols';
import { Confetti } from './components/Confetti';

// Helper to get human-readable cell names for the moves list
function getCellPositionName(index: number): string {
  const positions = [
    'Top-Left', 'Top-Center', 'Top-Right',
    'Middle-Left', 'Center', 'Middle-Right',
    'Bottom-Left', 'Bottom-Center', 'Bottom-Right'
  ];
  return positions[index] || `Cell ${index + 1}`;
}

export default function App() {
  // --- Persistent & Local States ---
  const [themeId, setThemeId] = useState<ThemeId>(() => {
    const saved = localStorage.getItem('ttt_theme');
    return (saved as ThemeId) || 'nordic';
  });

  const [gameMode, setGameMode] = useState<GameMode>(() => {
    const saved = localStorage.getItem('ttt_mode');
    return (saved as GameMode) || 'pvc';
  });

  const [difficulty, setDifficulty] = useState<Difficulty>(() => {
    const saved = localStorage.getItem('ttt_diff');
    return (saved as Difficulty) || 'medium';
  });

  const [playerSymbol, setPlayerSymbol] = useState<Player>(() => {
    const saved = localStorage.getItem('ttt_symbol');
    return (saved as Player) || 'X';
  });

  const [startingPlayer, setStartingPlayer] = useState<'X' | 'O' | 'random'>('X');

  const [isMuted, setIsMuted] = useState(() => audioService.getMuteStatus());

  // --- Core Game State ---
  const [board, setBoard] = useState<BoardState>(Array(9).fill(null));
  const [turn, setTurn] = useState<Player>('X');
  const [status, setStatus] = useState<GameStatus>('setup');
  const [winner, setWinner] = useState<Player | null>(null);
  const [winningCombo, setWinningCombo] = useState<number[] | null>(null);
  const [history, setHistory] = useState<GameMove[]>([]);
  const [isAiThinking, setIsAiThinking] = useState(false);
  const [showHowToPlay, setShowHowToPlay] = useState(false);

  // --- Scoreboard State ---
  const [score, setScore] = useState<Score>(() => {
    const saved = localStorage.getItem(`ttt_score_${gameMode}`);
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return { x: 0, o: 0, ties: 0 };
  });

  const activeTheme = THEMES[themeId] || THEMES.nordic;

  // Sync scores with gameMode changes
  useEffect(() => {
    const saved = localStorage.getItem(`ttt_score_${gameMode}`);
    if (saved) {
      try {
        setScore(JSON.parse(saved));
        return;
      } catch (e) { /* ignore */ }
    }
    setScore({ x: 0, o: 0, ties: 0 });
  }, [gameMode]);

  // Save config values on change
  useEffect(() => {
    localStorage.setItem('ttt_theme', themeId);
  }, [themeId]);

  useEffect(() => {
    localStorage.setItem('ttt_mode', gameMode);
  }, [gameMode]);

  useEffect(() => {
    localStorage.setItem('ttt_diff', difficulty);
  }, [difficulty]);

  useEffect(() => {
    localStorage.setItem('ttt_symbol', playerSymbol);
  }, [playerSymbol]);

  // --- Sound Toggle helper ---
  const handleToggleMute = () => {
    const muteState = audioService.toggleMute();
    setIsMuted(muteState);
    if (!muteState) {
      audioService.playClick();
    }
  };

  // --- Reset Scores ---
  const handleResetScores = () => {
    audioService.playClick();
    const newScore = { x: 0, o: 0, ties: 0 };
    setScore(newScore);
    localStorage.setItem(`ttt_score_${gameMode}`, JSON.stringify(newScore));
  };

  // --- Start Match ---
  const handleStartMatch = () => {
    audioService.playRestart();
    
    // Choose starting player
    let startSymbol: Player = 'X';
    if (startingPlayer === 'random') {
      startSymbol = Math.random() < 0.5 ? 'X' : 'O';
    } else {
      startSymbol = startingPlayer;
    }

    setBoard(Array(9).fill(null));
    setTurn(startSymbol);
    setStatus('playing');
    setWinner(null);
    setWinningCombo(null);
    setHistory([]);
    setIsAiThinking(false);
  };

  // --- Return to setup ---
  const handleReturnToSetup = () => {
    audioService.playClick();
    setStatus('setup');
  };

  // --- Handle Move (Player click) ---
  const handleCellClick = (index: number) => {
    // Block clicks if invalid state or AI turn or cell is already filled
    if (status !== 'playing' || board[index] !== null || isAiThinking) return;

    // In PVC mode, only allow clicking on human turn
    if (gameMode === 'pvc' && turn !== playerSymbol) return;

    makeMove(index, turn);
  };

  // --- Perform Move Logic ---
  const makeMove = useCallback((index: number, currentPlayer: Player) => {
    const newBoard = [...board];
    newBoard[index] = currentPlayer;

    // Sounds
    if (currentPlayer === 'X') {
      audioService.playPlaceX();
    } else {
      audioService.playPlaceO();
    }

    // Add to history log
    const now = new Date();
    const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const nextHistory: GameMove = {
      index,
      player: currentPlayer,
      timestamp: timeString
    };
    
    const updatedHistory = [...history, nextHistory];
    setHistory(updatedHistory);
    setBoard(newBoard);

    // Check game outcome
    const winResult = checkWinner(newBoard);
    if (winResult) {
      setWinner(winResult.winner);
      setWinningCombo(winResult.combination);
      setStatus('won');
      audioService.playWin();

      // Update scorecard
      const nextScore = { ...score };
      if (winResult.winner === 'X') nextScore.x += 1;
      else nextScore.o += 1;
      setScore(nextScore);
      localStorage.setItem(`ttt_score_${gameMode}`, JSON.stringify(nextScore));
      return;
    }

    if (isBoardFull(newBoard)) {
      setStatus('draw');
      audioService.playDraw();
      
      const nextScore = { ...score };
      nextScore.ties += 1;
      setScore(nextScore);
      localStorage.setItem(`ttt_score_${gameMode}`, JSON.stringify(nextScore));
      return;
    }

    // Pass turn
    setTurn(currentPlayer === 'X' ? 'O' : 'X');
  }, [board, history, score, gameMode]);

  // --- AI Player Effect Loop ---
  useEffect(() => {
    if (status !== 'playing' || gameMode !== 'pvc') return;

    const computerSymbol: Player = playerSymbol === 'X' ? 'O' : 'X';

    // If it is the AI's turn, compute its move
    if (turn === computerSymbol) {
      setIsAiThinking(true);

      // Custom delay (around 600ms) to simulate strategic calculation
      // which feels premium and responds well within the 5-second constraint.
      const timer = setTimeout(() => {
        const bestMove = computeComputerMove(board, computerSymbol, difficulty);
        if (bestMove !== -1) {
          makeMove(bestMove, computerSymbol);
        }
        setIsAiThinking(false);
      }, 600);

      return () => clearTimeout(timer);
    }
  }, [board, turn, gameMode, playerSymbol, status, difficulty, makeMove]);

  return (
    <div className={`min-h-screen ${activeTheme.bg} flex flex-col items-center justify-between p-4 sm:p-6 md:p-8 font-sans ${activeTheme.textPrimary} relative overflow-hidden transition-all duration-500`}>
      
      {/* Confetti Explosion on Win */}
      {status === 'won' && <Confetti />}

      {/* --- BACKGROUND ACCENTS --- */}
      <div className="absolute inset-0 pointer-events-none opacity-30">
        <div className="absolute top-[-10%] left-[-10%] w-[40vw] h-[40vw] rounded-full blur-[120px] bg-sky-400/20 theme-cyberpunk:bg-cyan-500/10 theme-matcha:bg-[#386641]/10 theme-amethyst:bg-violet-600/15" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40vw] h-[40vw] rounded-full blur-[120px] bg-emerald-400/20 theme-cyberpunk:bg-fuchsia-500/10 theme-matcha:bg-[#c05c46]/10 theme-amethyst:bg-amber-400/10" />
      </div>

      {/* --- GLOBAL APP BAR / HEADER --- */}
      <header className="w-full max-w-5xl flex items-center justify-between mb-4 z-10">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl border border-current/10 bg-current/5 flex items-center justify-center">
            <svg viewBox="0 0 100 100" className="w-6 h-6 stroke-current fill-none stroke-[10]" strokeLinecap="round">
              <line x1="15" y1="15" x2="85" y2="85" />
              <line x1="85" y1="15" x2="15" y2="85" />
            </svg>
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-display font-extrabold tracking-tight">
              Tic Tac Toe
            </h1>
            <p className="text-xs font-mono opacity-60">
              {gameMode === 'pvc' ? `Computer (${difficulty.toUpperCase()})` : 'Local Match'}
            </p>
          </div>
        </div>

        {/* Global Action Controls */}
        <div className="flex items-center gap-2">
          {/* Help Button */}
          <button
            id="btn-help-toggle"
            onClick={() => { audioService.playClick(); setShowHowToPlay(!showHowToPlay); }}
            className={`p-2 rounded-xl transition-all ${activeTheme.btnSecondaryBg} ${activeTheme.btnSecondaryText} ${activeTheme.btnSecondaryHover} flex items-center justify-center`}
            title="How to Play"
          >
            <Info className="w-5 h-5" />
          </button>

          {/* Sound Toggle */}
          <button
            id="btn-audio-toggle"
            onClick={handleToggleMute}
            className={`p-2 rounded-xl transition-all ${activeTheme.btnSecondaryBg} ${activeTheme.btnSecondaryText} ${activeTheme.btnSecondaryHover} flex items-center justify-center`}
            title={isMuted ? "Unmute Audio" : "Mute Audio"}
          >
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>
        </div>
      </header>

      {/* --- HOW TO PLAY DRAWER --- */}
      <AnimatePresence>
        {showHowToPlay && (
          <motion.div
            id="how-to-play-overlay"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => { audioService.playClick(); setShowHowToPlay(false); }}
          >
            <motion.div
              id="how-to-play-card"
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className={`max-w-md w-full p-6 ${activeTheme.cardBg} ${activeTheme.textPrimary} relative`}
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-xl font-display font-bold mb-4 flex items-center gap-2">
                <Info className="w-5 h-5 text-current" /> How to Play
              </h3>
              <div className="space-y-3 text-sm opacity-90 leading-relaxed font-sans">
                <p>
                  Tic Tac Toe is played on a <strong>3x3 grid</strong>. The first player to align <strong>three of their symbols</strong> (X or O) in a row, column, or diagonal wins the game!
                </p>
                <p className="font-semibold text-xs font-mono border-t border-current/10 pt-2.5 mt-2">
                  MODES & STRATEGIES
                </p>
                <ul className="list-disc pl-5 space-y-1.5 text-xs font-sans">
                  <li><strong>Player vs Player:</strong> Sit with a friend and take turns placing marks locally on the same device.</li>
                  <li><strong>Player vs Computer:</strong> Test your wits against our custom AI agent. Try <span className="text-emerald-500 font-semibold">Easy</span> for practice, <span className="text-amber-500 font-semibold">Medium</span> for a fair challenge, or <span className="text-violet-500 font-semibold">Hard</span> if you believe you cannot be beaten.</li>
                </ul>
              </div>
              <button
                id="btn-close-help"
                onClick={() => { audioService.playClick(); setShowHowToPlay(false); }}
                className={`mt-6 w-full py-2.5 px-4 rounded-xl font-medium transition-all ${activeTheme.btnPrimaryBg} ${activeTheme.btnPrimaryText} ${activeTheme.btnPrimaryHover}`}
              >
                Got It
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- MAIN CONTAINER --- */}
      <main className="w-full max-w-5xl flex-1 flex flex-col lg:flex-row items-center justify-center gap-6 lg:gap-10 z-10 py-4">

        {/* ========================================================= */}
        {/* SETUP SCREEN */}
        {/* ========================================================= */}
        <AnimatePresence mode="wait">
          {status === 'setup' && (
            <motion.div
              key="setup-screen"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className={`w-full max-w-xl p-6 md:p-8 ${activeTheme.cardBg} flex flex-col gap-6 md:gap-8`}
            >
              <div>
                <h2 className="text-2xl font-display font-extrabold tracking-tight">
                  Configure Your Match
                </h2>
                <p className="text-sm opacity-70 mt-1">
                  Customize the game rule parameters and start playing.
                </p>
              </div>

              {/* GAME MODE CARD SELECTOR */}
              <div className="flex flex-col gap-2.5">
                <label className="text-xs font-mono uppercase tracking-wider opacity-60">Game Mode</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    id="btn-mode-pvc"
                    onClick={() => { audioService.playClick(); setGameMode('pvc'); }}
                    className={`p-4 rounded-xl border flex flex-col items-center gap-2 text-center transition-all ${
                      gameMode === 'pvc'
                        ? `${activeTheme.accentBg} ${activeTheme.border} border-2`
                        : 'border-current/10 hover:bg-current/5'
                    }`}
                  >
                    <Cpu className={`w-6 h-6 ${gameMode === 'pvc' ? 'text-current scale-110' : 'opacity-65'} transition-all`} />
                    <div>
                      <div className="font-semibold text-sm">vs Computer</div>
                      <div className="text-xxs opacity-60 mt-0.5">Test your AI intelligence</div>
                    </div>
                  </button>

                  <button
                    id="btn-mode-pvp"
                    onClick={() => { audioService.playClick(); setGameMode('pvp'); }}
                    className={`p-4 rounded-xl border flex flex-col items-center gap-2 text-center transition-all ${
                      gameMode === 'pvp'
                        ? `${activeTheme.accentBg} ${activeTheme.border} border-2`
                        : 'border-current/10 hover:bg-current/5'
                    }`}
                  >
                    <User className={`w-6 h-6 ${gameMode === 'pvp' ? 'text-current scale-110' : 'opacity-65'} transition-all`} />
                    <div>
                      <div className="font-semibold text-sm">vs Player</div>
                      <div className="text-xxs opacity-60 mt-0.5">Local Pass & Play</div>
                    </div>
                  </button>
                </div>
              </div>

              {/* DYNAMIC SETTINGS DEPENDING ON MODE */}
              <AnimatePresence mode="popLayout">
                {gameMode === 'pvc' && (
                  <motion.div
                    key="pvc-settings"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="flex flex-col gap-5 overflow-hidden"
                  >
                    {/* DIFFICULTY SELECTOR */}
                    <div className="flex flex-col gap-2">
                      <label className="text-xs font-mono uppercase tracking-wider opacity-60">Difficulty Level</label>
                      <div className="grid grid-cols-3 gap-2">
                        {(['easy', 'medium', 'hard'] as const).map((diff) => (
                          <button
                            key={diff}
                            id={`btn-diff-${diff}`}
                            onClick={() => { audioService.playClick(); setDifficulty(diff); }}
                            className={`py-2.5 px-3 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all border ${
                              difficulty === diff
                                ? diff === 'easy'
                                  ? 'bg-emerald-500/10 border-emerald-500 text-emerald-500'
                                  : diff === 'medium'
                                  ? 'bg-amber-500/10 border-amber-500 text-amber-500'
                                  : 'bg-rose-500/10 border-rose-500 text-rose-500'
                                : 'border-current/10 hover:bg-current/5'
                            }`}
                          >
                            {diff}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* ASSIGN SYMBOLS */}
                    <div className="flex flex-col gap-2">
                      <label className="text-xs font-mono uppercase tracking-wider opacity-60">Your Symbol</label>
                      <div className="grid grid-cols-2 gap-3">
                        <button
                          id="btn-symbol-x"
                          onClick={() => { audioService.playClick(); setPlayerSymbol('X'); }}
                          className={`p-3 rounded-xl border flex items-center justify-center gap-3 transition-all ${
                            playerSymbol === 'X'
                              ? `${activeTheme.accentBg} ${activeTheme.border} border-2`
                              : 'border-current/10 hover:bg-current/5'
                          }`}
                        >
                          <MarkX size={24} animated={false} className={activeTheme.colorX} />
                          <span className="font-semibold text-sm">Play as X</span>
                        </button>
                        <button
                          id="btn-symbol-o"
                          onClick={() => { audioService.playClick(); setPlayerSymbol('O'); }}
                          className={`p-3 rounded-xl border flex items-center justify-center gap-3 transition-all ${
                            playerSymbol === 'O'
                              ? `${activeTheme.accentBg} ${activeTheme.border} border-2`
                              : 'border-current/10 hover:bg-current/5'
                          }`}
                        >
                          <MarkO size={24} animated={false} className={activeTheme.colorO} />
                          <span className="font-semibold text-sm">Play as O</span>
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* WHO GOES FIRST SELECTOR */}
              <div className="flex flex-col gap-2">
                <label className="text-xs font-mono uppercase tracking-wider opacity-60">First Turn</label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    id="btn-first-x"
                    onClick={() => { audioService.playClick(); setStartingPlayer('X'); }}
                    className={`py-2 rounded-lg text-xs font-medium transition-all ${
                      startingPlayer === 'X'
                        ? 'bg-current/15 border-2 border-current font-bold'
                        : 'border border-current/10 hover:bg-current/5'
                    }`}
                  >
                    X Goes First
                  </button>
                  <button
                    id="btn-first-o"
                    onClick={() => { audioService.playClick(); setStartingPlayer('O'); }}
                    className={`py-2 rounded-lg text-xs font-medium transition-all ${
                      startingPlayer === 'O'
                        ? 'bg-current/15 border-2 border-current font-bold'
                        : 'border border-current/10 hover:bg-current/5'
                    }`}
                  >
                    O Goes First
                  </button>
                  <button
                    id="btn-first-random"
                    onClick={() => { audioService.playClick(); setStartingPlayer('random'); }}
                    className={`py-2 rounded-lg text-xs font-medium transition-all ${
                      startingPlayer === 'random'
                        ? 'bg-current/15 border-2 border-current font-bold'
                        : 'border border-current/10 hover:bg-current/5'
                    }`}
                  >
                    Random
                  </button>
                </div>
              </div>

              {/* START BUTTON */}
              <button
                id="btn-start-match"
                onClick={handleStartMatch}
                className={`w-full py-4 px-6 rounded-xl font-display font-extrabold text-base tracking-wide flex items-center justify-center gap-2 shadow-sm cursor-pointer transition-all ${activeTheme.btnPrimaryBg} ${activeTheme.btnPrimaryText} ${activeTheme.btnPrimaryHover}`}
              >
                Start Match <ArrowRight className="w-5 h-5" />
              </button>
            </motion.div>
          )}

          {/* ========================================================= */}
          {/* GAMEBOARD PLAY SCREEN */}
          {/* ========================================================= */}
          {status !== 'setup' && (
            <motion.div
              key="playing-screen"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.3 }}
              className="w-full flex flex-col md:flex-row items-center lg:items-stretch justify-center gap-6 lg:gap-8"
            >
              
              {/* LEFT COLUMN: GAMEBOARD AND STATUS BAR */}
              <div className="flex-1 flex flex-col items-center justify-center gap-5 w-full">
                
                {/* MATCH STATUS HEADER BAR */}
                <div className={`w-full max-w-md px-4 py-3 ${activeTheme.cardBg} flex items-center justify-between shadow-sm`}>
                  <div className="flex items-center gap-3">
                    {/* Mode symbol */}
                    <div className="p-1.5 rounded-lg bg-current/10 text-xs">
                      {gameMode === 'pvc' ? <Cpu className="w-4 h-4 text-current" /> : <User className="w-4 h-4 text-current" />}
                    </div>
                    <div>
                      <div className="text-xs font-bold leading-none font-display">
                        {gameMode === 'pvc' ? `AI Match` : `Pass & Play`}
                      </div>
                      <div className="text-xxs font-mono opacity-60 leading-none mt-1">
                        {gameMode === 'pvc' ? `Difficulty: ${difficulty}` : `Local Game`}
                      </div>
                    </div>
                  </div>

                  {/* Active Player Turn Status */}
                  <div className="flex items-center gap-2 bg-current/5 py-1 px-2.5 rounded-full border border-current/10">
                    <span className="text-xs font-mono">Turn:</span>
                    <TurnIndicatorSymbol player={turn} size={14} className={turn === 'X' ? activeTheme.colorX : activeTheme.colorO} />
                    <span className="text-xs font-bold font-mono">{turn}</span>
                  </div>
                </div>

                {/* THE TIC TAC TOE GRID BOARD */}
                <div className="relative">
                  {/* Outer Grid Panel container */}
                  <div
                    id="tictactoe-grid-container"
                    className={`w-[320px] h-[320px] sm:w-[360px] sm:h-[360px] p-4 ${activeTheme.cardBg} relative overflow-hidden flex items-center justify-center`}
                  >
                    
                    {/* Grid Line Separators */}
                    <div className="absolute inset-4 grid grid-cols-3 grid-rows-3 pointer-events-none">
                      {/* Vertical line 1 */}
                      <div className={`absolute top-0 bottom-0 left-1/3 w-[2px] ${activeTheme.gridLine} translate-x-[-1px]`} />
                      {/* Vertical line 2 */}
                      <div className={`absolute top-0 bottom-0 left-2/3 w-[2px] ${activeTheme.gridLine} translate-x-[-1px]`} />
                      {/* Horizontal line 1 */}
                      <div className={`absolute left-0 right-0 top-1/3 h-[2px] ${activeTheme.gridLine} translate-y-[-1px]`} />
                      {/* Horizontal line 2 */}
                      <div className={`absolute left-0 right-0 top-2/3 h-[2px] ${activeTheme.gridLine} translate-y-[-1px]`} />
                    </div>

                    {/* Cells Layout */}
                    <div className="grid grid-cols-3 grid-rows-3 w-full h-full gap-2 relative z-10">
                      {board.map((cell, idx) => {
                        const isWinningCell = winningCombo?.includes(idx);
                        const isEmpty = cell === null;
                        const isHumanTurn = gameMode === 'pvp' || (gameMode === 'pvc' && turn === playerSymbol);
                        const isInteractable = status === 'playing' && isEmpty && !isAiThinking && isHumanTurn;

                        return (
                          <button
                            key={idx}
                            id={`cell-${idx}`}
                            onClick={() => handleCellClick(idx)}
                            disabled={!isInteractable}
                            className={`w-full h-full rounded-xl flex items-center justify-center relative transition-all duration-300 focus:outline-none ${
                              isWinningCell
                                ? cell === 'X'
                                  ? `${activeTheme.colorX} bg-sky-500/10 scale-95 shadow-md`
                                  : `${activeTheme.colorO} bg-emerald-500/10 scale-95 shadow-md`
                                : isInteractable
                                ? `cursor-pointer ${activeTheme.cellBg} ${activeTheme.cellHover}`
                                : 'cursor-default'
                            }`}
                          >
                            {/* Render Marks */}
                            <AnimatePresence mode="popLayout">
                              {cell === 'X' && (
                                <motion.div
                                  initial={{ scale: 0.3, opacity: 0 }}
                                  animate={{ scale: 1, opacity: 1 }}
                                  exit={{ scale: 0.3, opacity: 0 }}
                                  transition={{ type: 'spring', stiffness: 220, damping: 15 }}
                                  className="w-full h-full flex items-center justify-center p-4 sm:p-5 text-sky-500"
                                >
                                  <MarkX className={activeTheme.colorX} />
                                </motion.div>
                              )}
                              {cell === 'O' && (
                                <motion.div
                                  initial={{ scale: 0.3, opacity: 0 }}
                                  animate={{ scale: 1, opacity: 1 }}
                                  exit={{ scale: 0.3, opacity: 0 }}
                                  transition={{ type: 'spring', stiffness: 220, damping: 15 }}
                                  className="w-full h-full flex items-center justify-center p-4 sm:p-5 text-emerald-500"
                                >
                                  <MarkO className={activeTheme.colorO} />
                                </motion.div>
                              )}
                            </AnimatePresence>

                            {/* Hover Shadow Outline Guide for Humans */}
                            {isInteractable && (
                              <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-20 transition-opacity">
                                {turn === 'X' ? (
                                  <MarkX size={44} animated={false} className={activeTheme.colorX} />
                                ) : (
                                  <MarkO size={44} animated={false} className={activeTheme.colorO} />
                                )}
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* AI THINKING / WINNER CARD POPUP OVERLAYS */}
                  <AnimatePresence>
                    {isAiThinking && (
                      <motion.div
                        id="thinking-overlay"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="absolute inset-0 bg-black/40 backdrop-blur-[2px] z-20 rounded-2xl flex flex-col items-center justify-center gap-3"
                      >
                        <div className="relative">
                          <RefreshCw className="w-10 h-10 text-cyan-400 animate-spin" />
                          <Sparkles className="w-4 h-4 text-fuchsia-400 absolute top-[-4px] right-[-4px] animate-pulse" />
                        </div>
                        <p className="text-white text-sm font-mono font-bold uppercase tracking-widest drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                          AI Thinking...
                        </p>
                      </motion.div>
                    )}

                    {/* Game-Over (Won or Draw) Dialog overlay card */}
                    {status !== 'playing' && status !== 'setup' && (
                      <motion.div
                        id="gameover-overlay"
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="absolute inset-0 bg-black/65 backdrop-blur-[4px] z-30 rounded-2xl flex flex-col items-center justify-center p-6 text-center"
                      >
                        <motion.div
                          initial={{ y: 15, opacity: 0 }}
                          animate={{ y: 0, opacity: 1 }}
                          transition={{ delay: 0.15 }}
                          className="flex flex-col items-center"
                        >
                          {status === 'won' && winner ? (
                            <>
                              <div className="mb-2 p-3 bg-white/10 rounded-full border border-white/20">
                                <Trophy className="w-10 h-10 text-amber-400 drop-shadow-[0_0_10px_rgba(251,191,36,0.5)]" />
                              </div>
                              <h2 className="text-2xl md:text-3xl font-display font-black text-white tracking-tight drop-shadow">
                                Player {winner} Wins!
                              </h2>
                              <p className="text-white/80 text-xs font-mono uppercase tracking-wider mt-1.5 max-w-[200px]">
                                {gameMode === 'pvc'
                                  ? (winner === playerSymbol ? 'You beat the computer!' : 'The computer got you this time.')
                                  : 'Fabulous play, victory claimed!'}
                              </p>
                            </>
                          ) : (
                            <>
                              <div className="mb-2 p-3 bg-white/10 rounded-full border border-white/20">
                                <RefreshCw className="w-10 h-10 text-sky-300" />
                              </div>
                              <h2 className="text-2xl md:text-3xl font-display font-black text-white tracking-tight drop-shadow">
                                It's a Draw!
                              </h2>
                              <p className="text-white/80 text-xs font-mono uppercase tracking-wider mt-1.5">
                                A perfectly balanced match.
                              </p>
                            </>
                          )}

                          {/* Quick Game Action Buttons */}
                          <div className="mt-6 flex flex-col sm:flex-row gap-2.5 w-full min-w-[200px]">
                            <button
                              id="btn-quick-replay"
                              onClick={handleStartMatch}
                              className={`py-2.5 px-4 rounded-xl font-display font-extrabold text-sm tracking-wide flex items-center justify-center gap-2 cursor-pointer shadow-md ${activeTheme.btnPrimaryBg} ${activeTheme.btnPrimaryText} ${activeTheme.btnPrimaryHover}`}
                            >
                              <RotateCcw className="w-4 h-4" /> Rematch
                            </button>
                            <button
                              id="btn-return-setup"
                              onClick={handleReturnToSetup}
                              className={`py-2.5 px-4 rounded-xl font-display font-semibold text-sm tracking-wide flex items-center justify-center gap-2 cursor-pointer ${activeTheme.btnSecondaryBg} ${activeTheme.btnSecondaryText} ${activeTheme.btnSecondaryHover}`}
                            >
                              <Home className="w-4 h-4" /> Match Settings
                            </button>
                          </div>
                        </motion.div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* IN-GAME CONTROLS ROW */}
                <div className="flex items-center gap-3 w-full max-w-md justify-center">
                  <button
                    id="btn-game-restart"
                    onClick={handleStartMatch}
                    className={`flex-1 py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${activeTheme.btnPrimaryBg} ${activeTheme.btnPrimaryText} ${activeTheme.btnPrimaryHover}`}
                  >
                    <RotateCcw className="w-4 h-4" /> Restart Match
                  </button>
                  <button
                    id="btn-game-settings"
                    onClick={handleReturnToSetup}
                    className={`py-3 px-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${activeTheme.btnSecondaryBg} ${activeTheme.btnSecondaryText} ${activeTheme.btnSecondaryHover}`}
                    title="Change settings"
                  >
                    <Settings className="w-4 h-4" /> Settings
                  </button>
                </div>
              </div>

              {/* RIGHT COLUMN: SCORECARD & MATCH HISTORY LOG */}
              <div className="w-full md:w-[320px] flex flex-col gap-5">
                
                {/* 1. SCOREBOARD bento card */}
                <div className={`p-5 ${activeTheme.cardBg} shadow-sm flex flex-col gap-3.5`}>
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-display font-bold flex items-center gap-2 leading-none">
                      <Trophy className="w-4 h-4 text-amber-500" /> Scoreboard
                    </h3>
                    <button
                      id="btn-reset-scores"
                      onClick={handleResetScores}
                      className="text-xxs font-mono opacity-55 hover:opacity-100 transition-opacity uppercase tracking-wider"
                    >
                      Clear Record
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-2.5 text-center mt-1">
                    <div className="p-2.5 rounded-xl bg-current/5 border border-current/5 flex flex-col items-center">
                      <span className="text-xxs font-mono uppercase tracking-widest opacity-60">Wins (X)</span>
                      <span className="text-xl font-extrabold font-display mt-0.5">{score.x}</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-current/5 border border-current/5 flex flex-col items-center">
                      <span className="text-xxs font-mono uppercase tracking-widest opacity-60">Wins (O)</span>
                      <span className="text-xl font-extrabold font-display mt-0.5">{score.o}</span>
                    </div>
                    <div className="p-2.5 rounded-xl bg-current/5 border border-current/5 flex flex-col items-center">
                      <span className="text-xxs font-mono uppercase tracking-widest opacity-60">Ties</span>
                      <span className="text-xl font-extrabold font-display mt-0.5">{score.ties}</span>
                    </div>
                  </div>
                </div>

                {/* 2. MATCH HISTORY ACTIVITY LOG CARD */}
                <div className={`p-5 ${activeTheme.cardBg} shadow-sm flex-1 flex flex-col gap-3 min-h-[180px] max-h-[220px] md:max-h-none overflow-hidden`}>
                  <h3 className="text-sm font-display font-bold flex items-center gap-2 leading-none">
                    <History className="w-4 h-4" /> Match Log
                  </h3>

                  <div className="flex-1 overflow-y-auto pr-1 space-y-2 mt-1 scrollbar-thin">
                    {history.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-center p-4">
                        <p className="text-xs font-mono opacity-40 leading-relaxed italic">
                          No moves played yet. Tap any cell in the grid to begin!
                        </p>
                      </div>
                    ) : (
                      <div className="space-y-1.5">
                        {history.map((move, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between py-1.5 px-2 rounded-lg bg-current/5 border border-current/5 text-xs font-mono"
                          >
                            <div className="flex items-center gap-2">
                              <span className="opacity-40">#{idx + 1}</span>
                              <TurnIndicatorSymbol player={move.player} size={10} className={move.player === 'X' ? activeTheme.colorX : activeTheme.colorO} />
                              <span className="font-bold">{move.player}</span>
                              <span className="opacity-70">placed at</span>
                              <span className="font-semibold underline underline-offset-2">{getCellPositionName(move.index)}</span>
                            </div>
                            <span className="text-[10px] opacity-40">{move.timestamp}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              </div>

            </motion.div>
          )}
        </AnimatePresence>

      </main>

      {/* --- THEME CUSTOMIZER DRAWER (FOOTER) --- */}
      <footer className="w-full max-w-5xl flex flex-col items-center gap-4 border-t border-current/10 pt-4 mt-4 z-10">
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 opacity-70" />
          <span className="text-xs font-display font-bold uppercase tracking-wider opacity-70">Select Visual Interface Theme</span>
        </div>

        {/* 4 Theme Selection Circles/Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 w-full max-w-2xl">
          {Object.values(THEMES).map((t) => {
            const isSelected = t.id === themeId;
            return (
              <button
                key={t.id}
                id={`theme-btn-${t.id}`}
                onClick={() => {
                  audioService.playClick();
                  setThemeId(t.id);
                }}
                className={`py-2 px-3 rounded-xl border flex flex-col items-start gap-1 text-left transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-current/10 border-current font-bold shadow-sm scale-[1.02]'
                    : 'border-current/10 hover:bg-current/5 hover:scale-[1.01]'
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="text-xs font-display font-extrabold">{t.name}</span>
                  {/* Miniature color dots to show theme colors */}
                  <div className="flex gap-0.5">
                    <span className={`w-2 h-2 rounded-full ${t.id === 'nordic' ? 'bg-sky-500' : t.id === 'cyberpunk' ? 'bg-cyan-400' : t.id === 'matcha' ? 'bg-[#c05c46]' : 'bg-violet-400'}`} />
                    <span className={`w-2 h-2 rounded-full ${t.id === 'nordic' ? 'bg-emerald-500' : t.id === 'cyberpunk' ? 'bg-fuchsia-500' : t.id === 'matcha' ? 'bg-[#386641]' : 'bg-amber-400'}`} />
                  </div>
                </div>
                <span className="text-[10px] leading-tight opacity-60 font-sans font-normal line-clamp-1">
                  {t.description}
                </span>
              </button>
            );
          })}
        </div>

        <div className="text-[10px] font-mono opacity-40 mt-1">
          Tic Tac Toe Engine &bull; Crafted with React, Tailwind &amp; Motion &bull; Local Time: 2026
        </div>
      </footer>
    </div>
  );
}
