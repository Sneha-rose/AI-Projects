/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class AudioService {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;

  private init() {
    if (!this.ctx && typeof window !== 'undefined') {
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        this.ctx = new AudioCtx();
      } catch (e) {
        console.warn('Web Audio API not supported in this browser:', e);
      }
    }
    // Resume context if suspended (common browser security behavior)
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  getMuteStatus(): boolean {
    return this.isMuted;
  }

  private playTone(freq: number, type: OscillatorType, duration: number, gainStart: number, delay: number = 0) {
    this.init();
    if (!this.ctx || this.isMuted) return;

    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime + delay);

    gainNode.gain.setValueAtTime(gainStart, this.ctx.currentTime + delay);
    // Exponential decay
    gainNode.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + delay + duration);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(this.ctx.currentTime + delay);
    osc.stop(this.ctx.currentTime + delay + duration);
  }

  playClick() {
    // Elegant soft tick
    this.playTone(800, 'sine', 0.05, 0.05);
  }

  playPlaceX() {
    // Bright, slightly modern electronic pluck (rising)
    this.playTone(440, 'triangle', 0.12, 0.15);
    this.playTone(554.37, 'sine', 0.15, 0.1, 0.04); // C#5
  }

  playPlaceO() {
    // Softer, rounder pluck (descending)
    this.playTone(523.25, 'triangle', 0.12, 0.15); // C5
    this.playTone(392.00, 'sine', 0.15, 0.1, 0.04); // G4
  }

  playWin() {
    // Delightful major arpeggio
    const now = 0;
    const notes = [261.63, 329.63, 392.00, 523.25]; // C4, E4, G4, C5
    notes.forEach((freq, index) => {
      this.playTone(freq, 'sine', 0.25, 0.15, now + index * 0.08);
    });
  }

  playDraw() {
    // Neutral double beep
    this.playTone(293.66, 'triangle', 0.15, 0.1); // D4
    this.playTone(220.00, 'triangle', 0.25, 0.1, 0.12); // A3
  }

  playRestart() {
    // Quick pleasant swipe/scale up
    const notes = [349.23, 440.00, 523.25]; // F4, A4, C5
    notes.forEach((freq, index) => {
      this.playTone(freq, 'sine', 0.15, 0.08, index * 0.05);
    });
  }
}

export const audioService = new AudioService();
