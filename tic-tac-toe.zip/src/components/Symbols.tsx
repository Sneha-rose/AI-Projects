/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';

interface SymbolProps {
  className?: string;
  size?: number;
  animated?: boolean;
}

export const MarkX: React.FC<SymbolProps> = ({ className = '', size = 64, animated = true }) => {
  const lineVariants = {
    hidden: { pathLength: 0, opacity: 0 },
    visible: {
      pathLength: 1,
      opacity: 1,
      transition: {
        duration: 0.35,
        ease: 'easeOut',
      },
    },
  };

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      stroke="currentColor"
      strokeWidth="12"
      strokeLinecap="round"
      className={`${className} overflow-visible`}
      style={{ filter: 'drop-shadow(0 2px 8px currentColor)' }}
    >
      <motion.line
        x1="20"
        y1="20"
        x2="80"
        y2="80"
        variants={animated ? lineVariants : undefined}
        initial="hidden"
        animate="visible"
      />
      <motion.line
        x1="80"
        y1="20"
        x2="20"
        y2="80"
        variants={animated ? lineVariants : undefined}
        initial="hidden"
        animate="visible"
        transition={{ delay: animated ? 0.15 : 0 }}
      />
    </svg>
  );
};

export const MarkO: React.FC<SymbolProps> = ({ className = '', size = 64, animated = true }) => {
  const circleVariants = {
    hidden: { pathLength: 0, opacity: 0, rotate: -90 },
    visible: {
      pathLength: 1,
      opacity: 1,
      rotate: 0,
      transition: {
        duration: 0.45,
        ease: 'easeInOut',
      },
    },
  };

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      stroke="currentColor"
      strokeWidth="12"
      strokeLinecap="round"
      className={`${className} overflow-visible`}
      style={{ filter: 'drop-shadow(0 2px 8px currentColor)' }}
    >
      <motion.circle
        cx="50"
        cy="50"
        r="30"
        variants={animated ? circleVariants : undefined}
        initial="hidden"
        animate="visible"
      />
    </svg>
  );
};

interface IndicatorProps {
  player: 'X' | 'O';
  size?: number;
  className?: string;
  animated?: boolean;
}

export const TurnIndicatorSymbol: React.FC<IndicatorProps> = ({ player, size = 18, className = '', animated = false }) => {
  if (player === 'X') {
    return <MarkX size={size} className={className} animated={animated} />;
  }
  return <MarkO size={size} className={className} animated={animated} />;
};
