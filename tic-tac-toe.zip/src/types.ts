/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Player = 'X' | 'O';

export type CellValue = Player | null;

export type BoardState = CellValue[];

export type GameMode = 'pvp' | 'pvc';

export type Difficulty = 'easy' | 'medium' | 'hard';

export type GameStatus = 'setup' | 'playing' | 'won' | 'draw';

export type ThemeId = 'nordic' | 'cyberpunk' | 'matcha' | 'amethyst';

export interface ThemeConfig {
  id: ThemeId;
  name: string;
  description: string;
  class: string; // Tailwind class identifier for CSS scoping or body class
  bg: string; // App background
  cardBg: string; // Inner card / panel background
  textPrimary: string;
  textSecondary: string;
  border: string;
  gridLine: string;
  
  // Custom cell styles
  cellBg: string;
  cellHover: string;
  cellText: string;
  
  // Colors for X and O
  colorX: string;
  colorO: string;
  glowX?: string;
  glowO?: string;
  
  // Primary action button styling
  btnPrimaryBg: string;
  btnPrimaryText: string;
  btnPrimaryHover: string;
  
  // Secondary button styling
  btnSecondaryBg: string;
  btnSecondaryText: string;
  btnSecondaryHover: string;
  
  // Interactive details
  accentColor: string;
  accentBg: string;
  accentHover: string;
}

export interface GameMove {
  index: number;
  player: Player;
  timestamp: string;
}

export interface Score {
  x: number;
  o: number;
  ties: number;
}
