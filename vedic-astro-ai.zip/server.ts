import { GoogleGenAI, Type } from "@google/genai";
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";

// Lazy-initialization helper for GoogleGenAI
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not defined. Please configure it in your Secrets panel.");
    }
    aiClient = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middleware for body parsing
  app.use(express.json());

  // API Endpoint to generate Indian Astrology Horoscope
  app.post("/api/horoscope", async (req, res) => {
    try {
      const { name, dob, tob, pob, gender, language } = req.body;

      if (!name || !dob || !tob || !pob || !gender) {
        return res.status(400).json({ error: "Missing required birth details (name, dob, tob, pob, gender)." });
      }

      const client = getAiClient();
      const currentLang = language || "English";

      // Vedic Astrological system prompt and detail injection
      const systemInstruction = `You are a highly experienced Indian Vedic Astrologer (Jyotish). 
Predict a daily fortune (today is ${new Date().toDateString()}) based on Indian Astrology standards (Rashi, Nakshatra, Lagna, Panchang) using the provided birth details.
IMPORTANT: You MUST generate all text content, labels, predictions, and descriptions strictly in the requested language: "${currentLang}". 
Make the descriptions culturally appropriate, positive, inspiring, and aligned with standard Vedic principles (Jyotish Shastra).
Avoid negative doom-predicting; offer constructively guided spiritual and practical advice (Upaya).
Ensure that the luckyColor is visually pleasant and luckyColorHex is a valid Tailwind-compatible hex code (e.g., '#FF7F50' for Coral/Saffron, '#4G...' is invalid, use real 6-character hex).`;

      const prompt = `Generate a daily Vedic horoscope prediction for:
Name: ${name}
Gender: ${gender}
Date of Birth: ${dob}
Time of Birth: ${tob}
Place of Birth: ${pob}
Target Language: ${currentLang}

Provide deep insights incorporating Chandra Rashi (Moon Sign), Nakshatra (Vedic Star Constellation), Ascendant (Lagna/Rising), and standard Indian Astrological predictions. Give a daily remedy (Upaya) and simple daily Panchang terms.`;

      // Define the response schema using Type from @google/genai to guarantee lightning-fast structured JSON return
      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: systemInstruction,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              zodiacSign: {
                type: Type.STRING,
                description: "Sun sign (Surya Rashi) e.g. Aries / Mesha"
              },
              moonSign: {
                type: Type.STRING,
                description: "Moon sign (Chandra Rashi) based on birth details"
              },
              nakshatra: {
                type: Type.STRING,
                description: "Vedic Nakshatra (birth star) e.g. Rohini, Ashwini"
              },
              ascendant: {
                type: Type.STRING,
                description: "Ascendant Sign (Lagna) e.g. Leo / Simha"
              },
              luckyColor: {
                type: Type.STRING,
                description: "The auspicious color of the day with a brief Vedic reason or advice"
              },
              luckyColorHex: {
                type: Type.STRING,
                description: "A valid CSS hex code matching the lucky color (e.g., #D2691E for Ochre, #FFBF00 for Amber)"
              },
              luckyNumber: {
                type: Type.STRING,
                description: "Lucky number of the day"
              },
              luckyTime: {
                type: Type.STRING,
                description: "The most auspicious daily time window (Muhurta) e.g. Abhijit Muhurta: 11:50 AM to 12:40 PM"
              },
              overallLuckScore: {
                type: Type.INTEGER,
                description: "Overall percentage score for the day, from 10 to 100"
              },
              scores: {
                type: Type.OBJECT,
                properties: {
                  career: { type: Type.INTEGER },
                  love: { type: Type.INTEGER },
                  finance: { type: Type.INTEGER },
                  health: { type: Type.INTEGER },
                  spiritual: { type: Type.INTEGER }
                },
                required: ["career", "love", "finance", "health", "spiritual"]
              },
              predictions: {
                type: Type.OBJECT,
                properties: {
                  overall: { type: Type.STRING, description: "General forecast of the day in details" },
                  career: { type: Type.STRING, description: "Detailed predictions and guidance regarding work/studies/business" },
                  love: { type: Type.STRING, description: "Predictions on family, relationships, and friendships" },
                  finance: { type: Type.STRING, description: "Predictions and caution about expenses, investments, or incoming wealth" },
                  health: { type: Type.STRING, description: "Guidance on wellness, mental peace, and energy levels" }
                },
                required: ["overall", "career", "love", "finance", "health"]
              },
              remedy: {
                type: Type.STRING,
                description: "An astrological remedy or daily positive action (Upaya) in Indian tradition, e.g., Offering water, mantra chanting, wearing specific colors"
              },
              panchang: {
                type: Type.OBJECT,
                properties: {
                  tithi: { type: Type.STRING, description: "Calculated/approximate Tithi of the day" },
                  yog: { type: Type.STRING, description: "Auspicious Yog" },
                  karan: { type: Type.STRING, description: "Vedic Karan" },
                  rahuKaal: { type: Type.STRING, description: "Approximate Rahu Kaal hours to avoid critical decisions" }
                },
                required: ["tithi", "yog", "karan", "rahuKaal"]
              }
            },
            required: [
              "zodiacSign",
              "moonSign",
              "nakshatra",
              "ascendant",
              "luckyColor",
              "luckyColorHex",
              "luckyNumber",
              "luckyTime",
              "overallLuckScore",
              "scores",
              "predictions",
              "remedy",
              "panchang"
            ]
          }
        }
      });

      const responseText = response.text;
      if (!responseText) {
        throw new Error("No response received from the AI model.");
      }

      const horoscopeData = JSON.parse(responseText.trim());
      return res.json({ success: true, horoscope: horoscopeData });

    } catch (error: any) {
      console.error("Horoscope Generation Error:", error);
      return res.status(500).json({ 
        error: error.message || "Failed to generate horoscope prediction. Please check your Gemini API key configuration." 
      });
    }
  });

  // Serve static assets in production, otherwise mount Vite in development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Vedic Astro AI] Server successfully started and running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start Express-Vite backend server:", err);
});
