export interface BirthProfile {
  name: string;
  dob: string; // YYYY-MM-DD
  tob: string; // HH:MM
  pob: string; // City, State, Country
  gender: "Male" | "Female" | "Other";
  language: string;
}

export interface PanchangData {
  tithi: string;
  yog: string;
  karan: string;
  rahuKaal: string;
}

export interface LuckScores {
  career: number;
  love: number;
  finance: number;
  health: number;
  spiritual: number;
}

export interface SectorPredictions {
  overall: string;
  career: string;
  love: string;
  finance: string;
  health: string;
}

export interface HoroscopeResponse {
  zodiacSign: string;
  moonSign: string;
  nakshatra: string;
  ascendant: string;
  luckyColor: string;
  luckyColorHex: string;
  luckyNumber: string;
  luckyTime: string;
  overallLuckScore: number;
  scores: LuckScores;
  predictions: SectorPredictions;
  remedy: string;
  panchang: PanchangData;
}

export interface AstroTheme {
  id: string;
  name: string;
  bg: string;
  card: string;
  accentText: string;
  accentBg: string;
  badge: string;
  iconColor: string;
  divider: string;
  tagline: string;
}
