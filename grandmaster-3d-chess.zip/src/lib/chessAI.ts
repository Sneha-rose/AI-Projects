import { Chess } from 'chess.js';
import { Difficulty } from '../types';

// Piece-Square Tables for positional evaluation.
// Values represent centipawns (1/100 of a pawn value).
// White perspective. For Black, we mirror the table vertically.

const pawnTable = [
  [0,  0,  0,  0,  0,  0,  0,  0],
  [50, 50, 50, 50, 50, 50, 50, 50],
  [10, 10, 20, 30, 30, 20, 10, 10],
  [5,  5, 10, 25, 25, 10,  5,  5],
  [0,  0,  0, 20, 20,  0,  0,  0],
  [5, -5,-10,  0,  0,-10, -5,  5],
  [5, 10, 10,-20,-20, 10, 10,  5],
  [0,  0,  0,  0,  0,  0,  0,  0]
];

const knightTable = [
  [-50,-40,-30,-30,-30,-30,-40,-50],
  [-40,-20,  0,  0,  0,  0,-20,-40],
  [-30,  0, 10, 15, 15, 10,  0,-30],
  [-30,  5, 15, 20, 20, 15,  5,-30],
  [-30,  0, 15, 20, 20, 15,  0,-30],
  [-30,  5, 10, 15, 15, 10,  5,-30],
  [-40,-20,  0,  5,  5,  0,-20,-40],
  [-50,-40,-30,-30,-30,-30,-40,-50]
];

const bishopTable = [
  [-20,-10,-10,-10,-10,-10,-10,-20],
  [-10,  0,  0,  0,  0,  0,  0,-10],
  [-10,  0,  5, 10, 10,  5,  0,-10],
  [-10,  5,  5, 10, 10,  5,  5,-10],
  [-10,  0, 10, 10, 10, 10,  0,-10],
  [-10, 10, 10, 10, 10, 10, 10,-10],
  [-10,  5,  0,  0,  0,  0,  5,-10],
  [-20,-10,-10,-10,-10,-10,-10,-20]
];

const rookTable = [
  [0,  0,  0,  0,  0,  0,  0,  0],
  [5, 10, 10, 10, 10, 10, 10,  5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [-5,  0,  0,  0,  0,  0,  0, -5],
  [0,  0,  0,  5,  5,  0,  0,  0]
];

const queenTable = [
  [-20,-10,-10, -5, -5,-10,-10,-20],
  [-10,  0,  0,  0,  0,  0,  0,-10],
  [-10,  0,  5,  5,  5,  5,  0,-10],
  [-5,  0,  5,  5,  5,  5,  0, -5],
  [0,  0,  5,  5,  5,  5,  0, -5],
  [-10,  5,  5,  5,  5,  5,  0,-10],
  [-10,  0,  5,  0,  0,  5,  0,-10],
  [-20,-10,-10, -5, -5,-10,-10,-20]
];

const kingMiddleGameTable = [
  [-30,-40,-40,-50,-50,-40,-40,-30],
  [-30,-40,-40,-50,-50,-40,-40,-30],
  [-30,-40,-40,-50,-50,-40,-40,-30],
  [-30,-40,-40,-50,-50,-40,-40,-30],
  [-20,-30,-30,-40,-40,-30,-30,-20],
  [-10,-20,-20,-20,-20,-20,-20,-10],
  [20, 20,  0,  0,  0,  0, 20, 20],
  [20, 30, 10,  0,  0, 10, 30, 20]
];

// In the endgame, the king should be active and move to the center
const kingEndGameTable = [
  [-50,-40,-30,-20,-20,-30,-40,-50],
  [-30,-20,-10,  0,  0,-10,-20,-30],
  [-30,-10, 20, 30, 30, 20,-10,-30],
  [-30,-10, 30, 40, 40, 30,-10,-30],
  [-30,-10, 30, 40, 40, 30,-10,-30],
  [-30,-10, 20, 30, 30, 20,-10,-30],
  [-30,-30,  0,  0,  0,  0,-30,-30],
  [-50,-30,-30,-30,-30,-30,-30,-50]
];

const PIECE_VALUES = {
  p: 100,
  n: 320,
  b: 330,
  r: 500,
  q: 900,
  k: 20000
};

// Check if we are in endgame (queens are off the board, or minor pieces only)
function isEndGame(chess: Chess): boolean {
  let whiteQueens = 0;
  let blackQueens = 0;
  let whiteMinors = 0;
  let blackMinors = 0;

  const board = chess.board();
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (piece) {
        if (piece.type === 'q') {
          if (piece.color === 'w') whiteQueens++;
          else blackQueens++;
        } else if (piece.type === 'r' || piece.type === 'b' || piece.type === 'n') {
          if (piece.color === 'w') whiteMinors++;
          else blackMinors++;
        }
      }
    }
  }

  // If no queens are left, or each side has at most one queen and very few minors, it's endgame
  if (whiteQueens === 0 && blackQueens === 0) return true;
  if (whiteQueens <= 1 && blackQueens <= 1) {
    if (whiteMinors <= 2 && blackMinors <= 2) return true;
  }
  return false;
}

// Evaluate the board from White's perspective
export function evaluateBoard(chess: Chess): number {
  if (chess.isCheckmate()) {
    // If it's checkmate and it's White's turn, Black won (return very negative)
    // If it's checkmate and it's Black's turn, White won (return very positive)
    return chess.turn() === 'w' ? -999999 : 999999;
  }
  
  if (chess.isDraw() || chess.isStalemate() || chess.isThreefoldRepetition()) {
    return 0; // Draw is neutral
  }

  const board = chess.board();
  let score = 0;
  const endgame = isEndGame(chess);

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const piece = board[r][c];
      if (piece) {
        const type = piece.type;
        const color = piece.color;
        let pieceValue = PIECE_VALUES[type];
        
        // Piece-Square table positional evaluation
        let pstValue = 0;
        
        // Mirror row index for black pieces
        const tableRow = color === 'w' ? r : 7 - r;
        const tableCol = c;

        switch (type) {
          case 'p':
            pstValue = pawnTable[tableRow][tableCol];
            break;
          case 'n':
            pstValue = knightTable[tableRow][tableCol];
            break;
          case 'b':
            pstValue = bishopTable[tableRow][tableCol];
            break;
          case 'r':
            pstValue = rookTable[tableRow][tableCol];
            break;
          case 'q':
            pstValue = queenTable[tableRow][tableCol];
            break;
          case 'k':
            pstValue = endgame 
              ? kingEndGameTable[tableRow][tableCol] 
              : kingMiddleGameTable[tableRow][tableCol];
            break;
        }

        const totalValue = pieceValue + pstValue;
        
        if (color === 'w') {
          score += totalValue;
        } else {
          score -= totalValue;
        }
      }
    }
  }

  return score;
}

// Order moves for alpha-beta efficiency (evaluating captures and promotions first)
function orderMoves(chess: Chess, moves: any[]): any[] {
  return [...moves].sort((a, b) => {
    let scoreA = 0;
    let scoreB = 0;

    // Check if capture
    if (a.captured) {
      scoreA += 10 * PIECE_VALUES[a.captured as keyof typeof PIECE_VALUES] - PIECE_VALUES[a.piece as keyof typeof PIECE_VALUES];
    }
    if (b.captured) {
      scoreB += 10 * PIECE_VALUES[b.captured as keyof typeof PIECE_VALUES] - PIECE_VALUES[b.piece as keyof typeof PIECE_VALUES];
    }

    // Check if promotion
    if (a.promotion) scoreA += 900;
    if (b.promotion) scoreB += 900;

    // Give priority to check
    chess.move(a);
    if (chess.inCheck()) scoreA += 50;
    chess.undo();

    chess.move(b);
    if (chess.inCheck()) scoreB += 50;
    chess.undo();

    return scoreB - scoreA;
  });
}

// Minimax with Alpha-Beta pruning
function minimax(
  chess: Chess,
  depth: number,
  alpha: number,
  beta: number,
  isMaximizingPlayer: boolean
): { score: number; move: any | null } {
  if (depth === 0 || chess.isGameOver()) {
    return { score: evaluateBoard(chess), move: null };
  }

  const moves = orderMoves(chess, chess.moves({ verbose: true }));
  let bestMove = null;

  if (isMaximizingPlayer) {
    let maxEval = -Infinity;
    for (const move of moves) {
      chess.move(move);
      const evaluation = minimax(chess, depth - 1, alpha, beta, false).score;
      chess.undo();

      if (evaluation > maxEval) {
        maxEval = evaluation;
        bestMove = move;
      }
      alpha = Math.max(alpha, evaluation);
      if (beta <= alpha) {
        break; // Beta cut-off
      }
    }
    return { score: maxEval, move: bestMove };
  } else {
    let minEval = Infinity;
    for (const move of moves) {
      chess.move(move);
      const evaluation = minimax(chess, depth - 1, alpha, beta, true).score;
      chess.undo();

      if (evaluation < minEval) {
        minEval = evaluation;
        bestMove = move;
      }
      beta = Math.min(beta, evaluation);
      if (beta <= alpha) {
        break; // Alpha cut-off
      }
    }
    return { score: minEval, move: bestMove };
  }
}

// Computes the best move based on current game state and difficulty
export function getComputerMove(fen: string, difficulty: Difficulty): any {
  const chess = new Chess(fen);
  const moves = chess.moves({ verbose: true });
  
  if (moves.length === 0) return null;

  // Easy mode: Depth 1 minimax, or 30% chance of a completely random valid move to make human-like blunders
  if (difficulty === 'easy') {
    if (Math.random() < 0.35) {
      const randomIndex = Math.floor(Math.random() * moves.length);
      return moves[randomIndex];
    }
    
    // Depth 1 evaluation
    const isWhite = chess.turn() === 'w';
    const result = minimax(chess, 1, -Infinity, Infinity, isWhite);
    return result.move || moves[0];
  }

  // Medium mode: Depth 2 minimax. Solid play without deep search overhead
  if (difficulty === 'medium') {
    // 10% chance of slightly suboptimal move to mimic intermediate players
    if (Math.random() < 0.10) {
      const randomIndex = Math.floor(Math.random() * moves.length);
      return moves[randomIndex];
    }
    const isWhite = chess.turn() === 'w';
    const result = minimax(chess, 2, -Infinity, Infinity, isWhite);
    return result.move || moves[0];
  }

  // Hard mode: Depth 3 search with alpha-beta and move ordering. Super challenging and lightning fast!
  const isWhite = chess.turn() === 'w';
  
  // Adaptive depth: If few pieces are left (endgame), we can search deeper (depth 4) safely
  const endgame = isEndGame(chess);
  const depth = endgame ? 4 : 3;

  const result = minimax(chess, depth, -Infinity, Infinity, isWhite);
  return result.move || moves[0];
}
