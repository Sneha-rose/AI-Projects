import React from 'react';
import { X, BookOpen, Crown, ShieldAlert, Award } from 'lucide-react';

interface ChessRulesModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ChessRulesModal: React.FC<ChessRulesModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="relative w-full max-w-2xl max-h-[85vh] overflow-y-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 text-slate-100 flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <BookOpen className="w-6 h-6 text-emerald-400" />
            <h2 className="text-xl font-bold font-sans tracking-tight">Official Chess Rules & Mechanics</h2>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto pr-1 my-4 space-y-6 text-sm leading-relaxed text-slate-300">
          
          {/* Objective */}
          <div className="p-4 bg-slate-800/40 border border-slate-800 rounded-xl">
            <div className="flex items-center space-x-2 text-emerald-400 font-semibold mb-2">
              <Crown className="w-4 h-4" />
              <span>Core Objective</span>
            </div>
            <p>
              Chess is played between two opponents on an 8x8 grid board. The game is won when a player puts the opponent's King in <strong>Checkmate</strong> — a state where the King is under immediate attack (in check) and has no legal moves to escape.
            </p>
          </div>

          {/* Piece Movements */}
          <div>
            <h3 className="text-base font-semibold text-slate-100 mb-3">Piece Movements</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-sans">
              <div className="p-3 bg-slate-800/20 border border-slate-800/60 rounded-lg">
                <span className="font-bold text-slate-200">♙ Pawn:</span> Moves 1 square forward (or 2 squares on its first move). Captures diagonally. Promotes upon reaching the opposite edge.
              </div>
              <div className="p-3 bg-slate-800/20 border border-slate-800/60 rounded-lg">
                <span className="font-bold text-slate-200">♘ Knight:</span> Moves in an "L-shape" (2 squares in one direction, 1 square perpendicular). The only piece that can jump over other pieces.
              </div>
              <div className="p-3 bg-slate-800/20 border border-slate-800/60 rounded-lg">
                <span className="font-bold text-slate-200">♗ Bishop:</span> Moves any number of squares diagonally. Stays on squares of its starting color.
              </div>
              <div className="p-3 bg-slate-800/20 border border-slate-800/60 rounded-lg">
                <span className="font-bold text-slate-200">♖ Rook:</span> Moves any number of squares horizontally or vertically. Key participant in Castling.
              </div>
              <div className="p-3 bg-slate-800/20 border border-slate-800/60 rounded-lg">
                <span className="font-bold text-slate-200">♕ Queen:</span> Moves any number of squares along diagonals, columns, or rows (combines Bishop and Rook paths).
              </div>
              <div className="p-3 bg-slate-800/20 border border-slate-800/60 rounded-lg">
                <span className="font-bold text-slate-200">♔ King:</span> Moves exactly 1 square in any direction. The game centers around protecting your King.
              </div>
            </div>
          </div>

          {/* Special Chess Moves */}
          <div>
            <h3 className="text-base font-semibold text-slate-100 mb-2">Special Chess Rules</h3>
            <div className="space-y-3">
              <div className="p-3 bg-slate-800/40 border border-slate-800 rounded-lg">
                <h4 className="font-bold text-emerald-400 mb-1">Castling</h4>
                <p className="text-xs">
                  A special defensive move involving both the King and the Rook. Under this rule, the King moves two squares toward a Rook, and that Rook hops over the King. Castling is only permitted if:
                </p>
                <ul className="list-disc list-inside text-xs mt-1 text-slate-400 space-y-0.5">
                  <li>Neither the King nor the Rook has moved in the game.</li>
                  <li>All squares between the King and the Rook are vacant.</li>
                  <li>The King is not currently in check, and does not cross or land on a square under attack.</li>
                </ul>
              </div>

              <div className="p-3 bg-slate-800/40 border border-slate-800 rounded-lg">
                <h4 className="font-bold text-emerald-400 mb-1">En Passant</h4>
                <p className="text-xs">
                  If an opponent's pawn makes a double-step forward and lands directly adjacent to your pawn, you may capture it "in passing" by moving diagonally behind it, as if it had only moved one square. This capture must be made on the very next turn.
                </p>
              </div>

              <div className="p-3 bg-slate-800/40 border border-slate-800 rounded-lg">
                <h4 className="font-bold text-emerald-400 mb-1">Pawn Promotion</h4>
                <p className="text-xs">
                  When a pawn reaches the eighth rank (the furthest side of the board), it is promoted to a Knight, Bishop, Rook, or Queen of the same color, replacing the pawn on that square.
                </p>
              </div>
            </div>
          </div>

          {/* Draw Conditions */}
          <div>
            <div className="flex items-center space-x-2 text-amber-400 font-semibold mb-2">
              <ShieldAlert className="w-4 h-4" />
              <span>Draw Conditions</span>
            </div>
            <div className="space-y-2 text-xs">
              <p>
                <strong>Stalemate:</strong> Occurs when the active player has no legal moves available, but their King is not currently in check. The game ends immediately in a draw.
              </p>
              <p>
                <strong>Insufficient Material:</strong> A draw is declared if neither player has enough material to force a checkmate (e.g. King vs King, King & Knight vs King, King & Bishop vs King).
              </p>
              <p>
                <strong>Threefold Repetition:</strong> If the exact same position (including castling/en-passant rights) is repeated three times during a game, a draw can be claimed.
              </p>
              <p>
                <strong>50-Move Rule:</strong> If 50 consecutive moves have been made by each player without a pawn movement or a capture, a draw can be claimed.
              </p>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold rounded-lg bg-emerald-500 hover:bg-emerald-600 text-slate-950 transition-colors flex items-center space-x-1"
          >
            <Award className="w-4 h-4" />
            <span>Understood, Let's Play!</span>
          </button>
        </div>

      </div>
    </div>
  );
};
