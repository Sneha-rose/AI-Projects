import React from 'react';

interface ChessPieceProps {
  type: 'p' | 'n' | 'b' | 'r' | 'q' | 'k';
  color: 'w' | 'b';
  className?: string;
}

export const ChessPiece: React.FC<ChessPieceProps> = ({ type, color, className = "w-full h-full p-1" }) => {
  const isWhite = color === 'w';
  
  // Custom styled SVG pieces with elegant professional gradients and drop shadows
  const strokeColor = isWhite ? '#3A2E2B' : '#FFFFFF';
  const strokeWidth = '1.5';
  
  // High quality SVG paths for pieces
  switch (type) {
    case 'p': // Pawn
      return (
        <svg viewBox="0 0 45 45" className={className} id={`piece-p-${color}`}>
          <defs>
            <linearGradient id="white-pawn-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="60%" stopColor="#F5F3F0" />
              <stop offset="100%" stopColor="#DDD9D3" />
            </linearGradient>
            <linearGradient id="black-pawn-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#3E3D3C" />
              <stop offset="50%" stopColor="#222120" />
              <stop offset="100%" stopColor="#111111" />
            </linearGradient>
            <filter id="shadow" x="-10%" y="-10%" width="120%" height="120%">
              <feDropShadow dx="1" dy="2" stdDeviation="1.2" floodOpacity="0.4" />
            </filter>
          </defs>
          <g filter="url(#shadow)">
            <path
              d="M 22.5,9 C 24.24,9 25.65,7.59 25.65,5.85 C 25.65,4.11 24.24,2.7 22.5,2.7 C 20.76,2.7 19.35,4.11 19.35,5.85 C 19.35,7.59 20.76,9 22.5,9 z M 29,13.5 L 16,13.5 L 16,14.5 L 29,14.5 L 29,13.5 z M 29,18 L 16,18 C 16,25.5 13.5,29 13.5,35.5 L 31.5,35.5 C 31.5,29 29,25.5 29,18 z M 32.5,37.5 L 12.5,37.5 L 12.5,41 L 32.5,41 L 32.5,37.5 z"
              fill={isWhite ? 'url(#white-pawn-grad)' : 'url(#black-pawn-grad)'}
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
          </g>
        </svg>
      );
      
    case 'r': // Rook
      return (
        <svg viewBox="0 0 45 45" className={className} id={`piece-r-${color}`}>
          <defs>
            <linearGradient id="white-rook-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="60%" stopColor="#F5F3F0" />
              <stop offset="100%" stopColor="#DDD9D3" />
            </linearGradient>
            <linearGradient id="black-rook-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#3E3D3C" />
              <stop offset="50%" stopColor="#222120" />
              <stop offset="100%" stopColor="#111111" />
            </linearGradient>
          </defs>
          <g filter="url(#shadow)">
            <path
              d="M 9,39 L 36,39 L 36,36 L 9,36 L 9,39 z M 12,36 L 33,36 L 30,21 L 15,21 L 12,36 z M 13,16 L 32,16 L 32,13 L 29,13 L 29,9 L 25,9 L 25,13 L 20,13 L 20,9 L 16,9 L 16,13 L 13,13 L 13,16 z M 9,42.3 L 36,42.3 L 36,39 L 9,39 L 9,42.3 z"
              fill={isWhite ? 'url(#white-rook-grad)' : 'url(#black-rook-grad)'}
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
          </g>
        </svg>
      );
      
    case 'n': // Knight
      return (
        <svg viewBox="0 0 45 45" className={className} id={`piece-n-${color}`}>
          <defs>
            <linearGradient id="white-knight-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="60%" stopColor="#F5F3F0" />
              <stop offset="100%" stopColor="#DDD9D3" />
            </linearGradient>
            <linearGradient id="black-knight-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#3E3D3C" />
              <stop offset="50%" stopColor="#222120" />
              <stop offset="100%" stopColor="#111111" />
            </linearGradient>
          </defs>
          <g filter="url(#shadow)">
            <path
              d="M 22,10 C 22,10 19,11 16,15 C 13,19 13,23 13,23 C 13,23 14,20 18,20 C 18,20 17,21 15,24 C 13,27 13,31 16,33 C 16,33 15,31 17,30 C 19,29 22,28 23,29 C 23,29 22,30 20,31 C 18,32 17,34 18,36 C 19,38 21,38 23,37 C 25,36 27,33 28,30 C 29,27 29,21 28,18 C 27,15 25,12 22,10 z M 22,10 C 22,10 24,6 29,6 C 34,6 37,10 37,13 C 37,16 35,21 34,22 C 33,23 31,23 30,22 C 29,21 29,19 30,18 C 31,17 32,15 31,13 C 30,11 27,11 26,12 C 25,13 24,15 24,15 C 24,15 23,12 22,10 z M 9,39 L 36,39 L 36,42 L 9,42 L 9,39 z"
              fill={isWhite ? 'url(#white-knight-grad)' : 'url(#black-knight-grad)'}
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
          </g>
        </svg>
      );
      
    case 'b': // Bishop
      return (
        <svg viewBox="0 0 45 45" className={className} id={`piece-b-${color}`}>
          <defs>
            <linearGradient id="white-bishop-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="60%" stopColor="#F5F3F0" />
              <stop offset="100%" stopColor="#DDD9D3" />
            </linearGradient>
            <linearGradient id="black-bishop-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#3E3D3C" />
              <stop offset="50%" stopColor="#222120" />
              <stop offset="100%" stopColor="#111111" />
            </linearGradient>
          </defs>
          <g filter="url(#shadow)">
            <path
              d="M 9,36 C 9,36 22.5,37 22.5,28 C 22.5,28 26.5,26.5 28,21.5 C 29.5,16.5 28.5,12 25,8.5 C 21.5,12 20.5,16.5 22,21.5 C 23.5,26.5 22.5,28 22.5,28 C 22.5,28 9,36 9,36 z M 22.5,2.5 C 21.5,2.5 20.5,3.5 20.5,4.5 C 20.5,5.5 21.5,6.5 22.5,6.5 C 23.5,6.5 24.5,5.5 24.5,4.5 C 24.5,3.5 23.5,2.5 22.5,2.5 z M 17.5,18 L 27.5,18 M 22.5,13 L 22.5,23 M 9,39 L 36,39 L 36,42 L 9,42 L 9,39 z"
              fill={isWhite ? 'url(#white-bishop-grad)' : 'url(#black-bishop-grad)'}
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
          </g>
        </svg>
      );
      
    case 'q': // Queen
      return (
        <svg viewBox="0 0 45 45" className={className} id={`piece-q-${color}`}>
          <defs>
            <linearGradient id="white-queen-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="60%" stopColor="#F5F3F0" />
              <stop offset="100%" stopColor="#DDD9D3" />
            </linearGradient>
            <linearGradient id="black-queen-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#3E3D3C" />
              <stop offset="50%" stopColor="#222120" />
              <stop offset="100%" stopColor="#111111" />
            </linearGradient>
          </defs>
          <g filter="url(#shadow)">
            <path
              d="M 9,26 L 11.5,10.5 L 17.5,21.5 L 22.5,8 L 27.5,21.5 L 33.5,10.5 L 36,26 L 9,26 z M 9,26 C 9,26 9,32 11.5,34.5 L 33.5,34.5 C 36,32 36,26 36,26 M 9,37 L 36,37 L 36,40 L 9,40 L 9,37 z M 6,9 C 7.1,9 8,8.1 8,7 C 8,5.9 7.1,5 6,5 C 4.9,5 4,5.9 4,7 C 4,8.1 4.9,9 6,9 z M 17,9 C 18.1,9 19,8.1 19,7 C 19,5.9 18.1,5 17,5 C 15.9,5 15,5.9 15,7 C 15,8.1 15.9,9 17,9 z M 28,9 C 29.1,9 30,8.1 30,7 C 30,5.9 29.1,5 28,5 C 26.9,5 26,5.9 26,7 C 26,8.1 26.9,9 28,9 z M 39,9 C 40.1,9 41,8.1 41,7 C 41,5.9 40.1,5 39,5 C 37.9,5 37,5.9 37,7 C 37,8.1 37.9,9 39,9 z M 22.5,5 C 23.6,5 24.5,4.1 24.5,3 C 24.5,1.9 23.6,1 22.5,1 C 21.4,1 20.5,1.9 20.5,3 C 20.5,4.1 21.4,5 22.5,5 z"
              fill={isWhite ? 'url(#white-queen-grad)' : 'url(#black-queen-grad)'}
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
          </g>
        </svg>
      );
      
    case 'k': // King
      return (
        <svg viewBox="0 0 45 45" className={className} id={`piece-k-${color}`}>
          <defs>
            <linearGradient id="white-king-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="60%" stopColor="#F5F3F0" />
              <stop offset="100%" stopColor="#DDD9D3" />
            </linearGradient>
            <linearGradient id="black-king-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#3E3D3C" />
              <stop offset="50%" stopColor="#222120" />
              <stop offset="100%" stopColor="#111111" />
            </linearGradient>
          </defs>
          <g filter="url(#shadow)">
            <path
              d="M 9,36 C 9,36 12,38 22.5,38 C 33,38 36,36 36,36 L 33.5,21.5 L 29.5,27.5 L 22.5,14 L 15.5,27.5 L 11.5,21.5 L 9,36 z M 16,38 C 16,38 16,40.5 11.5,40.5 L 33.5,40.5 C 29,40.5 29,38 29,38 M 22.5,11 L 22.5,4 M 19,7.5 L 26,7.5"
              fill={isWhite ? 'url(#white-king-grad)' : 'url(#black-king-grad)'}
              stroke={strokeColor}
              strokeWidth={strokeWidth}
              strokeLinejoin="round"
            />
          </g>
        </svg>
      );
      
    default:
      return null;
  }
};
