import React, { useState, useEffect, useRef } from 'react';
import { Chess, Square } from 'chess.js';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Play, 
  Pause, 
  RotateCcw, 
  ChevronLeft, 
  ChevronRight, 
  ChevronsLeft, 
  ChevronsRight, 
  HelpCircle, 
  Sparkles, 
  User, 
  Monitor, 
  Timer, 
  Flame, 
  ShieldAlert, 
  Award,
  Maximize2,
  Minimize2,
  RefreshCw
} from 'lucide-react';

import { GameMode, Difficulty, BoardView, Theme, TimeControl, CapturedPiece, MoveRecord } from './types';
import { CHESS_THEMES, TIME_CONTROLS } from './data';
import { ChessPiece } from './components/ChessPieces';
import { ChessRulesModal } from './components/ChessRulesModal';
import { getComputerMove, evaluateBoard } from './lib/chessAI';

export default function App() {
  // Game Setup States
  const [gameMode, setGameMode] = useState<GameMode>('pvc');
  const [playerColor, setPlayerColor] = useState<'w' | 'b'>('w');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [activeTheme, setActiveTheme] = useState<Theme>(CHESS_THEMES[0]); // Classic Walnut
  const [timeControl, setTimeControl] = useState<TimeControl>(TIME_CONTROLS[3]); // Rapid 10+0
  
  // Custom Time Control States
  const [customMinutes, setCustomMinutes] = useState<number>(5);
  const [customIncrement, setCustomIncrement] = useState<number>(0);

  // Board View & Perspective
  const [is3dView, setIs3dView] = useState<boolean>(true);
  const [tiltAngle, setTiltAngle] = useState<number>(38);
  const [rotationAngle, setRotationAngle] = useState<number>(0);
  const [isFlipped, setIsFlipped] = useState<boolean>(false);

  // Active Game Engine States
  const [fen, setFen] = useState<string>('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  const [selectedSquare, setSelectedSquare] = useState<string | null>(null);
  const [validMoves, setValidMoves] = useState<string[]>([]);
  const [history, setHistory] = useState<MoveRecord[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1); // -1 means viewing active board
  const [lastMove, setLastMove] = useState<{ from: string; to: string; san: string } | null>(null);
  const [isThinking, setIsThinking] = useState<boolean>(false);

  // Clocks
  const [clocks, setClocks] = useState<{ w: number; b: number }>({ w: 600, b: 600 });
  const [isClockRunning, setIsClockRunning] = useState<boolean>(false);
  const [gameStatus, setGameStatus] = useState<'setup' | 'playing' | 'paused' | 'checkmate' | 'stalemate' | 'draw' | 'timeout'>('setup');
  const [winner, setWinner] = useState<'w' | 'b' | 'draw' | null>(null);

  // UI Modals
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);
  const [promotionPending, setPromotionPending] = useState<{ from: string; to: string } | null>(null);
  const [isAutoPlaying, setIsAutoPlaying] = useState<boolean>(false);

  // Refs
  const autoPlayTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Instantiate Chess.js engine helper
  const activeChessRef = useRef<Chess>(new Chess());

  // Reset or initialize clock times when time control changes
  useEffect(() => {
    if (gameStatus === 'setup') {
      const minutes = timeControl.id === 'custom' ? customMinutes : timeControl.minutes;
      const seconds = minutes * 60;
      setClocks({ w: seconds, b: seconds });
    }
  }, [timeControl, customMinutes, gameStatus]);

  // Synchronize board flip with player color selection in PVC
  useEffect(() => {
    if (gameMode === 'pvc') {
      setIsFlipped(playerColor === 'b');
    }
  }, [playerColor, gameMode]);

  // Active game clock countdown
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    
    if (gameStatus === 'playing' && isClockRunning && historyIndex === -1) {
      const currentChess = new Chess(fen);
      const activeColor = currentChess.turn();
      
      interval = setInterval(() => {
        setClocks(prev => {
          const nextTime = Math.max(0, prev[activeColor] - 0.1);
          if (nextTime === 0) {
            setGameStatus('timeout');
            setWinner(activeColor === 'w' ? 'b' : 'w');
            setIsClockRunning(false);
          }
          return {
            ...prev,
            [activeColor]: nextTime
          };
        });
      }, 100);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [gameStatus, isClockRunning, historyIndex, fen]);

  // Computer Opponent Turn Trigger
  useEffect(() => {
    if (gameStatus !== 'playing' || historyIndex !== -1 || isThinking) return;

    const currentChess = new Chess(fen);
    const activeColor = currentChess.turn();

    // Trigger AI move if it's the computer's turn
    const isComputerTurn = gameMode === 'pvc' && (
      (playerColor === 'w' && activeColor === 'b') ||
      (playerColor === 'b' && activeColor === 'w')
    );

    if (isComputerTurn) {
      setIsThinking(true);
      
      // Delay to give a highly realistic feeling of calculations
      const thinkTime = difficulty === 'easy' ? 400 : difficulty === 'medium' ? 700 : 900;
      
      const timer = setTimeout(() => {
        const aiMove = getComputerMove(fen, difficulty);
        if (aiMove) {
          executeMove(aiMove.from, aiMove.to, aiMove.promotion);
        }
        setIsThinking(false);
      }, thinkTime);

      return () => clearTimeout(timer);
    }
  }, [fen, gameStatus, gameMode, playerColor, difficulty, historyIndex]);

  // Handle auto playback timer
  useEffect(() => {
    if (isAutoPlaying) {
      autoPlayTimerRef.current = setInterval(() => {
        setHistoryIndex(prev => {
          if (prev < history.length - 1) {
            return prev + 1;
          } else {
            setIsAutoPlaying(false);
            return -1;
          }
        });
      }, 1500);
    } else {
      if (autoPlayTimerRef.current) {
        clearInterval(autoPlayTimerRef.current);
      }
    }

    return () => {
      if (autoPlayTimerRef.current) clearInterval(autoPlayTimerRef.current);
    };
  }, [isAutoPlaying, history.length]);

  // Start a new game
  const handleStartGame = () => {
    const freshChess = new Chess();
    activeChessRef.current = freshChess;
    setFen(freshChess.fen());
    setSelectedSquare(null);
    setValidMoves([]);
    setHistory([]);
    setHistoryIndex(-1);
    setLastMove(null);
    setIsThinking(false);
    
    const minutes = timeControl.id === 'custom' ? customMinutes : timeControl.minutes;
    const seconds = minutes * 60;
    setClocks({ w: seconds, b: seconds });
    
    setGameStatus('playing');
    setWinner(null);
    setIsClockRunning(true);
    setIsAutoPlaying(false);
  };

  // Reset current match state
  const handleResetGame = () => {
    setGameStatus('setup');
    setWinner(null);
    setIsClockRunning(false);
    setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
    setHistory([]);
    setHistoryIndex(-1);
    setLastMove(null);
    setSelectedSquare(null);
    setValidMoves([]);
  };

  // Core function to make moves
  const executeMove = (from: string, to: string, promotionPiece?: string) => {
    const currentChess = new Chess(fen);
    const movingColor = currentChess.turn();

    try {
      // Execute the move on Chess.js
      const move = currentChess.move({
        from: from as Square,
        to: to as Square,
        promotion: promotionPiece || 'q' // Auto-promote to Queen unless specified
      });

      if (move) {
        const nextFen = currentChess.fen();
        
        // Add increment to player's clock
        const currentIncrement = timeControl.id === 'custom' ? customIncrement : timeControl.increment;
        setClocks(prev => ({
          ...prev,
          [movingColor]: prev[movingColor] + currentIncrement
        }));

        // Record the move in history list
        const newRecord: MoveRecord = {
          san: move.san,
          from: move.from,
          to: move.to,
          color: move.color,
          piece: move.piece,
          captured: move.captured,
          promotion: promotionPiece,
          fen: nextFen
        };

        const updatedHistory = [...history, newRecord];
        setHistory(updatedHistory);
        setLastMove({ from, to, san: move.san });
        setFen(nextFen);
        setSelectedSquare(null);
        setValidMoves([]);
        setHistoryIndex(-1); // Always keep viewing live board after active move

        // Check for Game Ending Conditions
        if (currentChess.isCheckmate()) {
          setGameStatus('checkmate');
          setWinner(movingColor); // The player who made the last move wins!
          setIsClockRunning(false);
        } else if (currentChess.isStalemate()) {
          setGameStatus('stalemate');
          setWinner('draw');
          setIsClockRunning(false);
        } else if (currentChess.isDraw() || currentChess.isThreefoldRepetition() || currentChess.isInsufficientMaterial()) {
          setGameStatus('draw');
          setWinner('draw');
          setIsClockRunning(false);
        }
      }
    } catch (err) {
      console.error("Move Execution Failed", err);
    }
  };

  // Click handler for Chess Board squares
  const handleSquareClick = (square: string) => {
    // Lock movements if game not running, or computer thinking, or browsing history
    if (gameStatus !== 'playing' || isThinking || historyIndex !== -1) return;

    const currentChess = new Chess(fen);
    const activeColor = currentChess.turn();

    // Lock board for human if it is the Computer's turn in PVC
    const isComputerTurn = gameMode === 'pvc' && (
      (playerColor === 'w' && activeColor === 'b') ||
      (playerColor === 'b' && activeColor === 'w')
    );
    if (isComputerTurn) return;

    const piece = currentChess.get(square as Square);

    // If a piece is already selected and player clicked a valid destination square
    if (selectedSquare) {
      if (validMoves.includes(square)) {
        // Check if this move is a Pawn Promotion
        const selectedPiece = currentChess.get(selectedSquare as Square);
        const isPawn = selectedPiece?.type === 'p';
        const isPromotionRank = (selectedPiece?.color === 'w' && square.endsWith('8')) || 
                                (selectedPiece?.color === 'b' && square.endsWith('1'));

        if (isPawn && isPromotionRank) {
          setPromotionPending({ from: selectedSquare, to: square });
        } else {
          executeMove(selectedSquare, square);
        }
        return;
      }
    }

    // Otherwise select piece of current player color
    if (piece && piece.color === activeColor) {
      setSelectedSquare(square);
      // Generate standard legal moves from Chess.js
      const moves = currentChess.moves({ square: square as Square, verbose: true });
      setValidMoves(moves.map(m => m.to));
    } else {
      // Clear selection if clicked empty square or enemy piece (without active move)
      setSelectedSquare(null);
      setValidMoves([]);
    }
  };

  // Complete Pawn Promotion Choice
  const handlePromotionSelect = (pieceType: string) => {
    if (promotionPending) {
      executeMove(promotionPending.from, promotionPending.to, pieceType);
      setPromotionPending(null);
    }
  };

  // Format second countdown to highly accurate beautiful digital clock display
  const formatTime = (seconds: number) => {
    if (seconds <= 0) return "00:00.0";
    
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    const tenths = Math.floor((seconds % 1) * 10);
    
    const pad = (n: number) => n.toString().padStart(2, '0');
    
    // If under 10 seconds, show decimal precision for dynamic dramatic endgame tension!
    if (seconds <= 10) {
      return `${pad(secs)}.${tenths}`;
    }
    return `${pad(mins)}:${pad(secs)}`;
  };

  // Extract active/historical board FEN to render
  const renderFen = historyIndex === -1 ? fen : history[historyIndex].fen;
  const currentChessState = new Chess(renderFen);
  const currentBoard = currentChessState.board();

  // Find checking King's square to display red glow
  const activeCheckingColor = currentChessState.turn();
  const isCurrentlyInCheck = currentChessState.inCheck();
  
  const getKingSquare = (color: 'w' | 'b'): string | null => {
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = currentBoard[r][c];
        if (piece && piece.type === 'k' && piece.color === color) {
          const file = String.fromCharCode(97 + c);
          const rank = String(8 - r);
          return `${file}${rank}`;
        }
      }
    }
    return null;
  };

  const kingInCheckSquare = isCurrentlyInCheck ? getKingSquare(activeCheckingColor) : null;

  // Calculate Captured Pieces and Material scores
  const getCapturedSummary = (boardFen: string) => {
    const boardChess = new Chess(boardFen);
    const activePieces = {
      w: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 },
      b: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 }
    };

    const board = boardChess.board();
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const piece = board[r][c];
        if (piece) {
          activePieces[piece.color][piece.type]++;
        }
      }
    }

    const initialCounts = { p: 8, n: 2, b: 2, r: 2, q: 1, k: 1 };
    const wCaptured: { type: 'p' | 'n' | 'b' | 'r' | 'q' | 'k'; value: number }[] = [];
    const bCaptured: { type: 'p' | 'n' | 'b' | 'r' | 'q' | 'k'; value: number }[] = [];

    const pieceValues = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };

    (Object.keys(initialCounts) as Array<keyof typeof initialCounts>).forEach(type => {
      // White pieces captured by Black
      const wCapCount = initialCounts[type] - activePieces['w'][type];
      for (let i = 0; i < wCapCount; i++) {
        wCaptured.push({ type, value: pieceValues[type] });
      }

      // Black pieces captured by White
      const bCapCount = initialCounts[type] - activePieces['b'][type];
      for (let i = 0; i < bCapCount; i++) {
        bCaptured.push({ type, value: pieceValues[type] });
      }
    });

    // Compute active material point totals
    const wScore = wCaptured.reduce((sum, item) => sum + item.value, 0);
    const bScore = bCaptured.reduce((sum, item) => sum + item.value, 0);
    const scoreDiff = wScore - bScore;

    return {
      wCaptured, // White pieces captured (shown in Black's captures area)
      bCaptured, // Black pieces captured (shown in White's captures area)
      scoreDiff // Positive if White captures have higher value, negative if Black has more
    };
  };

  const capturedSummary = getCapturedSummary(renderFen);

  // Group historical moves into round lines for neat log visualization (e.g. 1. e4 e5)
  const renderMovePairs = () => {
    const pairs = [];
    for (let i = 0; i < history.length; i += 2) {
      pairs.push({
        round: Math.floor(i / 2) + 1,
        white: history[i],
        black: history[i + 1] || null,
        whiteIndex: i,
        blackIndex: i + 1
      });
    }
    return pairs;
  };

  // Navigations around the chess board history
  const handleHistoryFirst = () => {
    setIsAutoPlaying(false);
    if (history.length > 0) setHistoryIndex(0);
  };

  const handleHistoryPrev = () => {
    setIsAutoPlaying(false);
    setHistoryIndex(prev => {
      if (prev === -1) return history.length - 2 >= 0 ? history.length - 2 : 0;
      return Math.max(0, prev - 1);
    });
  };

  const handleHistoryNext = () => {
    setIsAutoPlaying(false);
    setHistoryIndex(prev => {
      if (prev === -1 || prev === history.length - 1) return -1;
      return prev + 1;
    });
  };

  const handleHistoryLast = () => {
    setIsAutoPlaying(false);
    setHistoryIndex(-1);
  };

  const toggleAutoPlay = () => {
    if (historyIndex === history.length - 1 || historyIndex === -1) {
      // If we are at end, restart auto play from beginning
      setHistoryIndex(0);
      setIsAutoPlaying(true);
    } else {
      setIsAutoPlaying(!isAutoPlaying);
    }
  };

  // Manual resign
  const handleResign = () => {
    if (gameStatus !== 'playing') return;
    const currentChess = new Chess(fen);
    const activeColor = currentChess.turn();
    setGameStatus('draw');
    setWinner(activeColor === 'w' ? 'b' : 'w');
    setIsClockRunning(false);
  };

  // Quick evaluation indicator
  const getPositionEvalLabel = () => {
    const evalScore = evaluateBoard(new Chess(renderFen));
    if (Math.abs(evalScore) < 50) return "Even Position";
    if (evalScore > 0) {
      if (evalScore > 500) return "White is Winning";
      return "White is slightly better";
    } else {
      if (evalScore < -500) return "Black is Winning";
      return "Black is slightly better";
    }
  };

  // Chess coordinates references
  const rows = [0, 1, 2, 3, 4, 5, 6, 7];
  const cols = [0, 1, 2, 3, 4, 5, 6, 7];

  // Adjust display board based on flipping
  const displayRows = isFlipped ? [...rows].reverse() : rows;
  const displayCols = isFlipped ? [...cols].reverse() : cols;

  return (
    <div className={`min-h-screen bg-gradient-to-br ${activeTheme.bgGradient} text-slate-100 flex flex-col items-center justify-between font-sans selection:bg-emerald-500/35 overflow-x-hidden p-3 md:p-6`}>
      
      {/* HEADER SECTION */}
      <header className="w-full max-w-7xl flex flex-col md:flex-row items-center justify-between gap-4 border-b border-slate-800/80 pb-4 mb-4">
        <div className="flex items-center space-x-3">
          <div className="bg-gradient-to-tr from-amber-500 to-emerald-500 p-2.5 rounded-xl shadow-lg ring-2 ring-emerald-500/20">
            <Sparkles className="w-6 h-6 text-slate-950" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-black tracking-tight bg-gradient-to-r from-amber-200 via-emerald-100 to-teal-200 bg-clip-text text-transparent">
              Grandmaster 3D Chess
            </h1>
            <p className="text-xs text-slate-400 font-mono">Precision Rules • AI engine • Immersive Space</p>
          </div>
        </div>

        {/* Top Controls */}
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setIsRulesOpen(true)}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800/80 border border-slate-700/60 text-slate-300 hover:text-slate-100 hover:bg-slate-700/90 transition-all cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 text-emerald-400" />
            <span>Rules</span>
          </button>
          
          <button
            onClick={() => setIsFlipped(!isFlipped)}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800/80 border border-slate-700/60 text-slate-300 hover:text-slate-100 hover:bg-slate-700/90 transition-all cursor-pointer"
          >
            <RefreshCw className="w-4 h-4 text-amber-400" />
            <span>Flip Board</span>
          </button>
        </div>
      </header>

      {/* MAIN GAME GRID */}
      <main className="w-full max-w-7xl flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: CONTROLS & SETUP (4 Cols) */}
        <div className="lg:col-span-3 space-y-4">
          
          {/* MATCH CONFIGURATOR PANEL */}
          <div className="bg-slate-950/40 border border-slate-800/80 p-4 rounded-2xl shadow-xl space-y-4">
            <h3 className="text-sm font-semibold text-slate-200 tracking-wider uppercase font-mono border-b border-slate-800/60 pb-2">
              Match Setup
            </h3>

            {/* Game Mode */}
            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 font-medium">Opponent Type</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setGameMode('pvc');
                    if (gameStatus === 'playing') handleResetGame();
                  }}
                  className={`flex items-center justify-center space-x-1 py-2 px-3 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                    gameMode === 'pvc'
                      ? 'bg-emerald-500/20 border-emerald-500/60 text-emerald-300 shadow-md shadow-emerald-500/5'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
                  }`}
                >
                  <Monitor className="w-3.5 h-3.5" />
                  <span>VS Computer</span>
                </button>
                <button
                  onClick={() => {
                    setGameMode('pvp');
                    if (gameStatus === 'playing') handleResetGame();
                  }}
                  className={`flex items-center justify-center space-x-1 py-2 px-3 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                    gameMode === 'pvp'
                      ? 'bg-emerald-500/20 border-emerald-500/60 text-emerald-300 shadow-md shadow-emerald-500/5'
                      : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800/50 hover:text-slate-200'
                  }`}
                >
                  <User className="w-3.5 h-3.5" />
                  <span>Pass & Play</span>
                </button>
              </div>
            </div>

            {/* AI Setup (Only visible if PVC) */}
            {gameMode === 'pvc' && (
              <div className="space-y-3 pt-1 animate-fade-in">
                <div className="space-y-1">
                  <label className="text-xs text-slate-400 font-medium">Your Piece Color</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => {
                        setPlayerColor('w');
                        if (gameStatus === 'playing') handleResetGame();
                      }}
                      className={`py-1.5 px-3 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                        playerColor === 'w'
                          ? 'bg-white text-slate-950 border-white'
                          : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:bg-slate-800/40'
                      }`}
                    >
                      White (Goes First)
                    </button>
                    <button
                      onClick={() => {
                        setPlayerColor('b');
                        if (gameStatus === 'playing') handleResetGame();
                      }}
                      className={`py-1.5 px-3 rounded-lg text-xs font-bold border transition-all cursor-pointer ${
                        playerColor === 'b'
                          ? 'bg-slate-800 text-white border-slate-700'
                          : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:bg-slate-800/40'
                      }`}
                    >
                      Black
                    </button>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-xs text-slate-400 font-medium">AI Strength</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {(['easy', 'medium', 'hard'] as const).map(level => (
                      <button
                        key={level}
                        onClick={() => setDifficulty(level)}
                        className={`py-1.5 px-2 rounded-lg text-xs font-bold capitalize border transition-all cursor-pointer ${
                          difficulty === level
                            ? level === 'easy'
                              ? 'bg-amber-500/20 border-amber-500/60 text-amber-300'
                              : level === 'medium'
                                ? 'bg-emerald-500/20 border-emerald-500/60 text-emerald-300'
                                : 'bg-rose-500/20 border-rose-500/60 text-rose-300 font-extrabold'
                            : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                        }`}
                      >
                        {level}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Time Control */}
            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 font-medium">Timer Clock</label>
              <div className="grid grid-cols-2 gap-1.5">
                {TIME_CONTROLS.map(tc => (
                  <button
                    key={tc.id}
                    onClick={() => {
                      setTimeControl(tc);
                      if (gameStatus === 'playing') handleResetGame();
                    }}
                    className={`py-1.5 px-2.5 rounded-lg text-xs font-semibold border transition-all text-left cursor-pointer ${
                      timeControl.id === tc.id
                        ? 'bg-emerald-500/20 border-emerald-500/60 text-emerald-300'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                    }`}
                  >
                    {tc.name}
                  </button>
                ))}
              </div>

              {/* Custom Time Control Sliders */}
              {timeControl.id === 'custom' && (
                <div className="p-3 bg-slate-900/60 border border-slate-800/80 rounded-xl space-y-3 mt-2 animate-fade-in">
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-400">Time Limit:</span>
                      <span className="text-emerald-300 font-bold">{customMinutes} min</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="60"
                      value={customMinutes}
                      onChange={(e) => {
                        setCustomMinutes(parseInt(e.target.value));
                        if (gameStatus === 'playing') handleResetGame();
                      }}
                      className="w-full accent-emerald-500 cursor-pointer h-1 rounded-lg"
                    />
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-400">Bonus Increment:</span>
                      <span className="text-emerald-300 font-bold">+{customIncrement}s / move</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="30"
                      value={customIncrement}
                      onChange={(e) => {
                        setCustomIncrement(parseInt(e.target.value));
                        if (gameStatus === 'playing') handleResetGame();
                      }}
                      className="w-full accent-emerald-500 cursor-pointer h-1 rounded-lg"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Play Button */}
            {gameStatus === 'setup' ? (
              <button
                onClick={handleStartGame}
                className="w-full py-3 px-4 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-slate-950 font-black text-sm rounded-xl shadow-lg hover:shadow-emerald-500/15 hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer flex items-center justify-center space-x-2"
              >
                <Play className="w-4 h-4 fill-slate-950" />
                <span>START MATCH</span>
              </button>
            ) : (
              <button
                onClick={handleResetGame}
                className="w-full py-2.5 px-4 bg-slate-800 border border-slate-700/60 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl transition-all cursor-pointer flex items-center justify-center space-x-2"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>EXIT MATCH TO SETUP</span>
              </button>
            )}

          </div>

          {/* THEMES & VISUALS COLOURED PANEL */}
          <div className="bg-slate-950/40 border border-slate-800/80 p-4 rounded-2xl shadow-xl space-y-4">
            <h3 className="text-sm font-semibold text-slate-200 tracking-wider uppercase font-mono border-b border-slate-800/60 pb-2">
              Aesthetics & View
            </h3>

            {/* Selected Theme */}
            <div className="space-y-1.5">
              <label className="text-xs text-slate-400 font-medium">Board Theme Combo</label>
              <div className="grid grid-cols-1 gap-1.5">
                {CHESS_THEMES.map(theme => (
                  <button
                    key={theme.id}
                    onClick={() => setActiveTheme(theme)}
                    className={`flex items-center justify-between p-2 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                      activeTheme.id === theme.id
                        ? 'bg-slate-800/80 border-slate-600 text-white shadow-inner'
                        : 'bg-slate-900/40 border-slate-800/80 text-slate-400 hover:bg-slate-800/30'
                    }`}
                  >
                    <div className="flex items-center space-x-2">
                      {/* Colour preview dots */}
                      <span className="flex rounded-md overflow-hidden ring-1 ring-white/10">
                        <span className="w-3 h-3 block" style={{ backgroundColor: theme.lightSquare }} />
                        <span className="w-3 h-3 block" style={{ backgroundColor: theme.darkSquare }} />
                      </span>
                      <span>{theme.name}</span>
                    </div>
                    {activeTheme.id === theme.id && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />}
                  </button>
                ))}
              </div>
            </div>

            {/* 3D vs 2D Perspective Toggle */}
            <div className="space-y-2 pt-1 border-t border-slate-800/40">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-400 font-medium">3D Perspective View</span>
                <button
                  onClick={() => setIs3dView(!is3dView)}
                  className={`relative inline-flex h-5 w-10 items-center rounded-full transition-colors focus:outline-none cursor-pointer ${
                    is3dView ? 'bg-emerald-500' : 'bg-slate-800'
                  }`}
                >
                  <span
                    className={`inline-block h-3.5 w-3.5 transform rounded-full bg-slate-950 transition-transform ${
                      is3dView ? 'translate-x-5' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>

              {/* 3D sliders */}
              {is3dView && (
                <div className="space-y-2.5 p-2.5 bg-slate-900/60 border border-slate-850/80 rounded-xl mt-1 animate-fade-in">
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] font-mono text-slate-400">
                      <span>Tilt Angle:</span>
                      <span>{tiltAngle}°</span>
                    </div>
                    <input
                      type="range"
                      min="15"
                      max="55"
                      value={tiltAngle}
                      onChange={(e) => setTiltAngle(parseInt(e.target.value))}
                      className="w-full accent-emerald-500 h-1 cursor-pointer"
                    />
                  </div>
                  <div className="space-y-1">
                    <div className="flex justify-between text-[10px] font-mono text-slate-400">
                      <span>Rotation:</span>
                      <span>{rotationAngle}°</span>
                    </div>
                    <input
                      type="range"
                      min="-35"
                      max="35"
                      value={rotationAngle}
                      onChange={(e) => setRotationAngle(parseInt(e.target.value))}
                      className="w-full accent-emerald-500 h-1 cursor-pointer"
                    />
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>

        {/* CENTER COLUMN: THE ARENA BOARD (6 Cols) */}
        <div className="lg:col-span-6 flex flex-col items-center justify-center space-y-4">
          
          {/* OPPONENT STATS & CLOCK ROW */}
          <div className="w-full flex items-center justify-between bg-slate-950/20 border border-slate-800/40 px-4 py-2.5 rounded-xl">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs border border-slate-700 font-bold text-slate-300">
                {gameMode === 'pvc' ? <Monitor className="w-4 h-4 text-emerald-400" /> : "B"}
              </div>
              <div>
                <div className="text-xs font-bold flex items-center space-x-1.5">
                  <span className="text-slate-200">
                    {gameMode === 'pvc' ? `AI Opponent (${difficulty})` : 'Black Player'}
                  </span>
                  {historyIndex === -1 && gameStatus === 'playing' && currentChessState.turn() === 'b' && (
                    <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse" />
                  )}
                </div>
                {/* Black captured pieces */}
                <div className="flex flex-wrap gap-0.5 mt-0.5 h-4 items-center">
                  {capturedSummary.wCaptured.map((piece, idx) => (
                    <span key={idx} className="w-3 h-3 opacity-80 filter drop-shadow">
                      <ChessPiece type={piece.type} color="w" className="w-full h-full p-0" />
                    </span>
                  ))}
                  {capturedSummary.scoreDiff < 0 && (
                    <span className="text-[10px] text-red-400 font-extrabold ml-1 font-mono">
                      +{Math.abs(capturedSummary.scoreDiff)}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Black Clock */}
            <div className={`px-4 py-2 rounded-xl border font-mono font-black text-lg transition-all flex items-center space-x-1.5 ${
              currentChessState.turn() === 'b' && gameStatus === 'playing' && historyIndex === -1
                ? clocks.b <= 15
                  ? 'bg-red-950/80 border-red-500/80 text-red-200 animate-pulse'
                  : 'bg-emerald-950/50 border-emerald-500/60 text-emerald-300'
                : 'bg-slate-900/60 border-slate-800 text-slate-400'
            }`}>
              <Timer className="w-4 h-4" />
              <span>{formatTime(clocks.b)}</span>
            </div>
          </div>

          {/* CHESSBOARD PERSPECTIVE STAGE */}
          <div 
            className="relative flex items-center justify-center w-full max-w-[500px] aspect-square transition-all duration-500 select-none pb-4"
            style={{
              perspective: '1200px',
              perspectiveOrigin: '50% 30%',
            }}
          >
            <div
              className="relative w-full h-full transition-all duration-500 ease-out flex items-center justify-center"
              style={{
                transform: is3dView 
                  ? `rotateX(${tiltAngle}deg) rotateY(${rotationAngle}deg) translateZ(0px)` 
                  : 'rotateX(0deg) rotateY(0deg)',
                transformStyle: 'preserve-3d',
                boxShadow: is3dView ? '0 30px 60px rgba(0,0,0,0.8), 0 10px 20px rgba(0,0,0,0.4)' : 'none',
                borderRadius: '16px',
              }}
            >
              
              {/* Outer Board Wooden Border Trim */}
              <div 
                className="absolute inset-[-14px] rounded-2xl pointer-events-none border border-slate-950 shadow-2xl"
                style={{
                  backgroundColor: activeTheme.boardBorder,
                  transform: 'translateZ(-6px)',
                  boxShadow: 'inset 0 4px 12px rgba(255,255,255,0.1), inset 0 -4px 12px rgba(0,0,0,0.4)',
                }}
              />

              {/* Grid Wrapper */}
              <div className="grid grid-cols-8 grid-rows-8 w-full h-full rounded-lg overflow-hidden border border-slate-950/40 relative z-10 bg-slate-900">
                {displayRows.map(r => {
                  return displayCols.map(c => {
                    const file = String.fromCharCode(97 + c);
                    const rank = String(8 - r);
                    const squareId = `${file}${rank}`;
                    const isDark = (r + c) % 2 === 1;

                    // Locate chess piece on this cell
                    const cellPiece = currentBoard[r][c];

                    // Check highlight triggers
                    const isSelected = selectedSquare === squareId;
                    const isValidTarget = validMoves.includes(squareId);
                    const isLastMoveFrom = lastMove?.from === squareId;
                    const isLastMoveTo = lastMove?.to === squareId;
                    const isKingInCheck = kingInCheckSquare === squareId;

                    return (
                      <div
                        key={squareId}
                        id={`square-${squareId}`}
                        onClick={() => handleSquareClick(squareId)}
                        className="relative w-full h-full flex items-center justify-center cursor-pointer transition-all duration-150 group"
                        style={{
                          backgroundColor: isDark ? activeTheme.darkSquare : activeTheme.lightSquare,
                          transformStyle: 'preserve-3d',
                        }}
                      >
                        
                        {/* 3D Cell Depth Bevel overlay */}
                        {is3dView && (
                          <div 
                            className="absolute inset-x-0 bottom-0 h-[4px] opacity-75 pointer-events-none"
                            style={{
                              backgroundColor: isDark ? activeTheme.darkSquare3d : activeTheme.lightSquare3d,
                              transform: 'rotateX(90deg) translateZ(2px)',
                              transformOrigin: 'bottom',
                            }}
                          />
                        )}

                        {/* Overlays / Highlights */}
                        
                        {/* Selected Square Highlight */}
                        {isSelected && (
                          <div 
                            className="absolute inset-0 pointer-events-none z-10"
                            style={{ backgroundColor: activeTheme.selectedHighlight }}
                          />
                        )}

                        {/* Last Move Indicators */}
                        {(isLastMoveFrom || isLastMoveTo) && (
                          <div 
                            className="absolute inset-0 pointer-events-none z-10"
                            style={{ backgroundColor: activeTheme.lastMoveHighlight }}
                          />
                        )}

                        {/* King Check Red Glow */}
                        {isKingInCheck && (
                          <div className="absolute inset-0 pointer-events-none z-10 bg-red-500/40 animate-pulse border-2 border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.8)]" />
                        )}

                        {/* Valid target move visual cue */}
                        {isValidTarget && (
                          <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
                            {cellPiece ? (
                              // Circular bracket highlight for enemy piece capture
                              <div className="w-[85%] h-[85%] rounded-full border-4 border-amber-500/65" />
                            ) : (
                              // Soft dot for vacant move targets
                              <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: activeTheme.validMoveDot }} />
                            )}
                          </div>
                        )}

                        {/* Dynamic Coordinate Label at Board Borders */}
                        {/* Ranks on Left Side */}
                        {((!isFlipped && c === 0) || (isFlipped && c === 7)) && (
                          <span className="absolute top-1 left-1 text-[8px] md:text-[9px] font-mono leading-none opacity-40 select-none pointer-events-none font-black text-slate-800">
                            {rank}
                          </span>
                        )}
                        {/* Files on Bottom Side */}
                        {((!isFlipped && r === 7) || (isFlipped && r === 0)) && (
                          <span className="absolute bottom-1 right-1 text-[8px] md:text-[9px] font-mono leading-none opacity-40 select-none pointer-events-none font-black text-slate-800">
                            {file}
                          </span>
                        )}

                        {/* THE PIECE RENDERER */}
                        <AnimatePresence>
                          {cellPiece && (
                            <motion.div
                              key={`${cellPiece.type}-${cellPiece.color}`}
                              layoutId={`piece-${cellPiece.color}-${cellPiece.type}`}
                              className="w-[88%] h-[88%] relative z-25 flex items-center justify-center select-none cursor-grab active:cursor-grabbing"
                              style={{
                                transform: is3dView 
                                  ? `rotateX(${-tiltAngle}deg) rotateY(${-rotationAngle}deg) translateZ(10px)` 
                                  : 'none',
                                transformStyle: 'preserve-3d',
                              }}
                              whileHover={{ 
                                y: -6, 
                                scale: 1.05,
                                filter: 'drop-shadow(0 12px 14px rgba(0,0,0,0.5))' 
                              }}
                              whileTap={{ scale: 0.95 }}
                              transition={{ type: 'spring', stiffness: 220, damping: 20 }}
                            >
                              <ChessPiece type={cellPiece.type} color={cellPiece.color} />
                            </motion.div>
                          )}
                        </AnimatePresence>

                      </div>
                    );
                  });
                })}
              </div>

              {/* 3D Board Pedestal Base */}
              {is3dView && (
                <div 
                  className="absolute inset-x-[-14px] bottom-[-22px] h-[18px] pointer-events-none bg-slate-950 z-0"
                  style={{
                    transform: 'rotateX(90deg) translateZ(10px)',
                    transformOrigin: 'bottom',
                    boxShadow: '0 10px 30px rgba(0,0,0,0.8)',
                    borderRadius: '0 0 12px 12px',
                    borderColor: '#1e293b',
                    borderWidth: '1px',
                  }}
                />
              )}

            </div>
          </div>

          {/* ACTIVE HUMAN PLAYER STATS & CLOCK ROW */}
          <div className="w-full flex items-center justify-between bg-slate-950/20 border border-slate-800/40 px-4 py-2.5 rounded-xl">
            <div className="flex items-center space-x-2.5">
              <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs border border-slate-700 font-bold text-slate-300">
                {gameMode === 'pvc' ? <User className="w-4 h-4 text-emerald-400" /> : "W"}
              </div>
              <div>
                <div className="text-xs font-bold flex items-center space-x-1.5">
                  <span className="text-slate-200">
                    {gameMode === 'pvc' ? 'You (White)' : 'White Player'}
                  </span>
                  {historyIndex === -1 && gameStatus === 'playing' && currentChessState.turn() === 'w' && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  )}
                </div>
                {/* White captured pieces */}
                <div className="flex flex-wrap gap-0.5 mt-0.5 h-4 items-center">
                  {capturedSummary.bCaptured.map((piece, idx) => (
                    <span key={idx} className="w-3 h-3 opacity-80 filter drop-shadow">
                      <ChessPiece type={piece.type} color="b" className="w-full h-full p-0" />
                    </span>
                  ))}
                  {capturedSummary.scoreDiff > 0 && (
                    <span className="text-[10px] text-emerald-400 font-extrabold ml-1 font-mono">
                      +{capturedSummary.scoreDiff}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* White Clock */}
            <div className={`px-4 py-2 rounded-xl border font-mono font-black text-lg transition-all flex items-center space-x-1.5 ${
              currentChessState.turn() === 'w' && gameStatus === 'playing' && historyIndex === -1
                ? clocks.w <= 15
                  ? 'bg-red-950/80 border-red-500/80 text-red-200 animate-pulse'
                  : 'bg-emerald-950/50 border-emerald-500/60 text-emerald-300'
                : 'bg-slate-900/60 border-slate-800 text-slate-400'
            }`}>
              <Timer className="w-4 h-4" />
              <span>{formatTime(clocks.w)}</span>
            </div>
          </div>

          {/* ACTIVE IN-GAME CONTROLS (Pause/Resume, Resign, Draw) */}
          {gameStatus === 'playing' && (
            <div className="w-full grid grid-cols-3 gap-2 animate-fade-in">
              <button
                onClick={() => setIsClockRunning(!isClockRunning)}
                className={`flex items-center justify-center space-x-1 py-2 px-3 rounded-xl text-xs font-semibold border transition-all cursor-pointer ${
                  isClockRunning
                    ? 'bg-amber-500/10 border-amber-500/40 text-amber-300 hover:bg-amber-500/20'
                    : 'bg-emerald-500/20 border-emerald-500/60 text-emerald-300 hover:bg-emerald-500/30'
                }`}
              >
                {isClockRunning ? (
                  <>
                    <Pause className="w-3.5 h-3.5" />
                    <span>Pause Timer</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5" />
                    <span>Resume Timer</span>
                  </>
                )}
              </button>

              <button
                onClick={() => {
                  setGameStatus('draw');
                  setWinner('draw');
                  setIsClockRunning(false);
                }}
                className="flex items-center justify-center space-x-1 py-2 px-3 bg-slate-900/60 border border-slate-800 text-slate-300 hover:text-slate-100 hover:bg-slate-850 rounded-xl text-xs font-semibold transition-all cursor-pointer"
              >
                <span>Offer Draw</span>
              </button>

              <button
                onClick={handleResign}
                className="flex items-center justify-center space-x-1 py-2 px-3 bg-red-950/20 border border-red-900/30 text-red-300 hover:bg-red-950/40 rounded-xl text-xs font-semibold transition-all cursor-pointer"
              >
                <span>Resign Match</span>
              </button>
            </div>
          )}

        </div>

        {/* RIGHT COLUMN: ACTION PANEL & HISTORY (3 Cols) */}
        <div className="lg:col-span-3 space-y-4">
          
          {/* STATE BANNERS (GAME STATUS ALERTS) */}
          {gameStatus !== 'setup' && gameStatus !== 'playing' && (
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl shadow-xl flex flex-col items-center justify-center text-center space-y-3 animate-fade-in">
              <div className="p-3 bg-emerald-500/10 rounded-full border border-emerald-500/20 text-emerald-400">
                <Award className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-100 font-mono tracking-wider uppercase">Match Finished</h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  {gameStatus === 'checkmate' && `Checkmate! ${winner === 'w' ? 'White' : 'Black'} wins the match.`}
                  {gameStatus === 'stalemate' && `Stalemate! The match has concluded in a draw.`}
                  {gameStatus === 'draw' && `Draw claimed! Position is locked.`}
                  {gameStatus === 'timeout' && `Timeout! ${winner === 'w' ? 'White' : 'Black'} wins on time.`}
                </p>
              </div>
              <button
                onClick={handleResetGame}
                className="py-1.5 px-4 bg-emerald-500 hover:bg-emerald-600 text-slate-950 text-xs font-black rounded-lg shadow transition-all cursor-pointer"
              >
                New Game Setup
              </button>
            </div>
          )}

          {/* HISTORY NAVIGATION BOX */}
          <div className="bg-slate-950/40 border border-slate-800/80 p-4 rounded-2xl shadow-xl flex flex-col h-[280px]">
            <h3 className="text-sm font-semibold text-slate-200 tracking-wider uppercase font-mono border-b border-slate-800/60 pb-2 flex items-center justify-between">
              <span>Moves Log</span>
              <span className="text-[10px] text-slate-400 capitalize font-mono">
                {history.length} {history.length === 1 ? 'move' : 'moves'}
              </span>
            </h3>

            {/* Scrollable list of moves */}
            <div className="flex-1 overflow-y-auto pr-1 my-3 space-y-1 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
              {history.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-4">
                  <Flame className="w-5 h-5 text-slate-600 mb-1" />
                  <p className="text-[11px] text-slate-500 font-mono">No moves recorded yet. Begin your match!</p>
                </div>
              ) : (
                <div className="space-y-1 font-mono text-xs">
                  {renderMovePairs().map((pair) => (
                    <div 
                      key={pair.round} 
                      className={`grid grid-cols-12 py-1 px-2 rounded-lg items-center ${
                        pair.round % 2 === 1 ? 'bg-slate-900/30' : 'bg-transparent'
                      }`}
                    >
                      <span className="col-span-2 text-slate-500 font-bold">{pair.round}.</span>
                      
                      {/* White Move */}
                      <button
                        onClick={() => {
                          setIsAutoPlaying(false);
                          setHistoryIndex(pair.whiteIndex);
                        }}
                        className={`col-span-5 text-left font-semibold py-0.5 px-1 rounded hover:bg-slate-800 transition-colors cursor-pointer ${
                          historyIndex === pair.whiteIndex 
                            ? 'text-emerald-300 bg-emerald-500/10 font-black' 
                            : 'text-slate-200'
                        }`}
                      >
                        {pair.white.san}
                      </button>

                      {/* Black Move */}
                      {pair.black ? (
                        <button
                          onClick={() => {
                            setIsAutoPlaying(false);
                            setHistoryIndex(pair.blackIndex);
                          }}
                          className={`col-span-5 text-left font-semibold py-0.5 px-1 rounded hover:bg-slate-800 transition-colors cursor-pointer ${
                            historyIndex === pair.blackIndex 
                              ? 'text-emerald-300 bg-emerald-500/10 font-black' 
                              : 'text-slate-200'
                          }`}
                        >
                          {pair.black.san}
                        </button>
                      ) : (
                        <span className="col-span-5" />
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* NAVIGATION FOOTER MEDIA BUTTONS */}
            <div className="border-t border-slate-800/60 pt-3 flex flex-col space-y-2">
              
              {/* Media Controls */}
              <div className="flex items-center justify-between gap-1">
                <button
                  onClick={handleHistoryFirst}
                  disabled={history.length === 0}
                  className="flex-1 py-1 px-1 bg-slate-900 hover:bg-slate-850 disabled:opacity-40 rounded text-slate-300 disabled:cursor-not-allowed cursor-pointer flex justify-center"
                  title="First Move"
                >
                  <ChevronsLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={handleHistoryPrev}
                  disabled={history.length === 0}
                  className="flex-1 py-1 px-1 bg-slate-900 hover:bg-slate-850 disabled:opacity-40 rounded text-slate-300 disabled:cursor-not-allowed cursor-pointer flex justify-center"
                  title="Previous Move"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={toggleAutoPlay}
                  disabled={history.length === 0}
                  className={`flex-1 py-1 px-1 rounded font-semibold text-xs disabled:cursor-not-allowed cursor-pointer flex justify-center ${
                    isAutoPlaying 
                      ? 'bg-amber-500/20 border border-amber-500/40 text-amber-300' 
                      : 'bg-slate-900 hover:bg-slate-850 text-slate-300'
                  }`}
                  title={isAutoPlaying ? "Pause Playback" : "Auto Play Match"}
                >
                  {isAutoPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-slate-300" />}
                </button>
                <button
                  onClick={handleHistoryNext}
                  disabled={history.length === 0 || historyIndex === -1}
                  className="flex-1 py-1 px-1 bg-slate-900 hover:bg-slate-850 disabled:opacity-40 rounded text-slate-300 disabled:cursor-not-allowed cursor-pointer flex justify-center"
                  title="Next Move"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
                <button
                  onClick={handleHistoryLast}
                  disabled={history.length === 0 || historyIndex === -1}
                  className="flex-1 py-1 px-1 bg-slate-900 hover:bg-slate-850 disabled:opacity-40 rounded text-slate-300 disabled:cursor-not-allowed cursor-pointer flex justify-center"
                  title="Live Board"
                >
                  <ChevronsRight className="w-4 h-4" />
                </button>
              </div>

              {/* Status Indicator banner */}
              {historyIndex !== -1 && (
                <div className="bg-emerald-950/20 border border-emerald-900/30 p-2 rounded-lg text-center animate-pulse flex items-center justify-between">
                  <span className="text-[10px] text-emerald-400 font-mono font-bold">
                    Viewing Move {historyIndex + 1} of {history.length}
                  </span>
                  <button
                    onClick={handleHistoryLast}
                    className="text-[9px] bg-emerald-500 hover:bg-emerald-600 text-slate-950 px-1.5 py-0.5 font-black rounded uppercase cursor-pointer"
                  >
                    Go Live
                  </button>
                </div>
              )}
            </div>

          </div>

          {/* ACTIVE POSITION EVALUATION BOX */}
          <div className="bg-slate-950/40 border border-slate-800/80 p-4 rounded-2xl shadow-xl space-y-2">
            <h3 className="text-xs font-semibold text-slate-400 tracking-wider uppercase font-mono">
              Live Analysis Info
            </h3>
            <div className="p-3 bg-slate-900/40 border border-slate-850/60 rounded-xl space-y-1.5">
              <div className="text-xs font-bold text-slate-200 flex justify-between">
                <span>Evaluation Status:</span>
                <span className="text-amber-400 font-mono font-black">{getPositionEvalLabel()}</span>
              </div>
              <div className="text-[10px] text-slate-400 leading-tight">
                Evaluate based on piece-square position parameters. Turn indicators: <strong className="text-emerald-400 capitalize">{currentChessState.turn() === 'w' ? 'White' : 'Black'}</strong> moves next.
              </div>
            </div>
          </div>

        </div>

      </main>

      {/* FOOTER RULES NOTE BANNER */}
      <footer className="w-full max-w-7xl border-t border-slate-800/50 mt-4 pt-4 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-500">
        <p className="font-mono">© 2026 Grandmaster 3D Chess Room. Full compliance to FIDE regulations.</p>
        <button 
          onClick={() => setIsRulesOpen(true)}
          className="hover:text-slate-300 font-semibold flex items-center space-x-1 transition-colors cursor-pointer"
        >
          <HelpCircle className="w-4 h-4 text-emerald-500/60" />
          <span>Need help? Read the FIDE Rules of Chess</span>
        </button>
      </footer>

      {/* PAWN PROMOTION DECISION OVERLAY MODAL */}
      <AnimatePresence>
        {promotionPending && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm animate-fade-in">
            <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-2xl max-w-xs text-center space-y-4">
              <h3 className="text-base font-bold text-slate-100 font-sans">Pawn Promotion</h3>
              <p className="text-xs text-slate-400">Choose the piece to replace your pawn:</p>
              
              <div className="grid grid-cols-4 gap-2.5">
                {(['q', 'r', 'b', 'n'] as const).map(type => (
                  <button
                    key={type}
                    onClick={() => handlePromotionSelect(type)}
                    className="aspect-square bg-slate-800 hover:bg-slate-700/80 border border-slate-750/80 p-2.5 rounded-xl transition-all cursor-pointer flex items-center justify-center shadow-lg group hover:scale-[1.05]"
                  >
                    <ChessPiece type={type} color={currentChessState.turn() === 'w' ? 'w' : 'b'} className="w-full h-full group-hover:scale-105 transition-transform" />
                  </button>
                ))}
              </div>
              <p className="text-[10px] text-slate-500 font-mono">Usually promoting to Queen is ideal.</p>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* RULES MODAL */}
      <ChessRulesModal isOpen={isRulesOpen} onClose={() => setIsRulesOpen(false)} />

    </div>
  );
}
