import { Theme, TimeControl } from './types';

export const CHESS_THEMES: Theme[] = [
  {
    id: 'walnut',
    name: 'Classic Walnut',
    lightSquare: '#eedbb0',
    darkSquare: '#8b5a2b',
    lightSquare3d: '#f5e3be',
    darkSquare3d: '#a06a38',
    boardBorder: '#4a2c11',
    selectedHighlight: 'rgba(251, 191, 36, 0.5)', // Amber-400 50%
    lastMoveHighlight: 'rgba(251, 191, 36, 0.35)',
    validMoveDot: 'rgba(180, 83, 9, 0.7)', // Amber-700
    bgGradient: 'from-amber-950 via-slate-900 to-slate-950',
    panelBg: 'bg-amber-950/20 border-amber-900/30',
    textColor: 'text-amber-100',
  },
  {
    id: 'forest',
    name: 'Tournament Emerald',
    lightSquare: '#f0f2eb',
    darkSquare: '#4b7355',
    lightSquare3d: '#f9fbf4',
    darkSquare3d: '#568462',
    boardBorder: '#233827',
    selectedHighlight: 'rgba(52, 211, 153, 0.5)', // Emerald-400 50%
    lastMoveHighlight: 'rgba(52, 211, 153, 0.35)',
    validMoveDot: 'rgba(4, 120, 87, 0.7)', // Emerald-700
    bgGradient: 'from-emerald-950 via-slate-900 to-slate-950',
    panelBg: 'bg-emerald-950/20 border-emerald-900/30',
    textColor: 'text-emerald-100',
  },
  {
    id: 'championship',
    name: 'Championship Blue',
    lightSquare: '#eceff1',
    darkSquare: '#546e7a',
    lightSquare3d: '#f5f7f8',
    darkSquare3d: '#607d8b',
    boardBorder: '#263238',
    selectedHighlight: 'rgba(56, 189, 248, 0.5)', // Sky-400 50%
    lastMoveHighlight: 'rgba(56, 189, 248, 0.35)',
    validMoveDot: 'rgba(3, 105, 161, 0.7)', // Sky-700
    bgGradient: 'from-sky-950 via-slate-900 to-slate-950',
    panelBg: 'bg-sky-950/20 border-sky-900/30',
    textColor: 'text-sky-100',
  },
  {
    id: 'obsidian',
    name: 'Midnight Tech',
    lightSquare: '#475569', // Slate-600
    darkSquare: '#1e293b', // Slate-800
    lightSquare3d: '#64748b', // Slate-500
    darkSquare3d: '#334155', // Slate-700
    boardBorder: '#0f172a', // Slate-900
    selectedHighlight: 'rgba(168, 85, 247, 0.5)', // Purple-500 50%
    lastMoveHighlight: 'rgba(168, 85, 247, 0.35)',
    validMoveDot: 'rgba(147, 51, 234, 0.7)', // Purple-600
    bgGradient: 'from-indigo-950 via-slate-900 to-slate-950',
    panelBg: 'bg-indigo-950/20 border-indigo-900/30',
    textColor: 'text-indigo-100',
  },
  {
    id: 'royal',
    name: 'Imperial Velvet',
    lightSquare: '#f3e5d8',
    darkSquare: '#7d1919',
    lightSquare3d: '#faebd7',
    darkSquare3d: '#8f2020',
    boardBorder: '#3d0808',
    selectedHighlight: 'rgba(244, 63, 94, 0.5)', // Rose-500 50%
    lastMoveHighlight: 'rgba(244, 63, 94, 0.35)',
    validMoveDot: 'rgba(190, 24, 74, 0.7)', // Rose-700
    bgGradient: 'from-rose-950 via-slate-900 to-slate-950',
    panelBg: 'bg-rose-950/20 border-rose-900/30',
    textColor: 'text-rose-100',
  },
];

export const TIME_CONTROLS: TimeControl[] = [
  { id: 'bullet', name: 'Bullet 1+0', minutes: 1, increment: 0 },
  { id: 'blitz3', name: 'Blitz 3+2', minutes: 3, increment: 2 },
  { id: 'blitz5', name: 'Blitz 5+0', minutes: 5, increment: 0 },
  { id: 'rapid', name: 'Rapid 10+0', minutes: 10, increment: 0 },
  { id: 'classical', name: 'Classical 30+0', minutes: 30, increment: 0 },
  { id: 'custom', name: 'Custom Time', minutes: 5, increment: 0 },
];
