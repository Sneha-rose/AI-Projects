export type GameMode = 'pvp' | 'pvc';
export type Difficulty = 'easy' | 'medium' | 'hard';
export type BoardView = '2d' | '3d';

export interface Theme {
  id: string;
  name: string;
  lightSquare: string;
  darkSquare: string;
  lightSquare3d: string; // Used for realistic 3D bevel / top surface
  darkSquare3d: string;
  boardBorder: string;
  selectedHighlight: string;
  lastMoveHighlight: string;
  validMoveDot: string;
  bgGradient: string;
  panelBg: string;
  textColor: string;
}

export interface TimeControl {
  id: string;
  name: string;
  minutes: number;
  increment: number;
}

export interface CapturedPiece {
  id: string;
  type: 'p' | 'n' | 'b' | 'r' | 'q' | 'k';
  color: 'w' | 'b';
}

export interface MoveRecord {
  san: string;
  from: string;
  to: string;
  color: 'w' | 'b';
  piece: string;
  captured?: string;
  promotion?: string;
  fen: string;
}
